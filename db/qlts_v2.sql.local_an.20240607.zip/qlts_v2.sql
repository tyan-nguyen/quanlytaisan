-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 27, 2024 at 03:15 PM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlts_v2`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('macDinh', 20, 1691653806),
('nDuyetBaoGiaSuaChua', 1, 1717077666),
('nDuyetBaoGiaSuaChua', 2, 1717078477),
('nQuanLyPhieuSuaChua', 1, 1717077666),
('nQuanLyVatTuKho', 1, 1717077666),
('user_1_', 1, 1691485394),
('user_20_', 20, 1691975112),
('user_4_', 4, 1691396411);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//ajaxcrud', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//controller', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//crud', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//extension', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//form', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//model', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('//module', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/asset/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/asset/compress', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/asset/template', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/baotri/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/default/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/default/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/ke-hoach-bao-tri/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/ke-hoach-bao-tri/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/ke-hoach-bao-tri/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/ke-hoach-bao-tri/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/ke-hoach-bao-tri/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/ke-hoach-bao-tri/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/ke-hoach-bao-tri/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/lich-bao-tri/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/lich-bao-tri/baotri', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/baotri/lich-bao-tri/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/lich-bao-tri/test', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/baotri/lich-bao-tri/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/baotri/loai-bao-tri/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/loai-bao-tri/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/loai-bao-tri/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/loai-bao-tri/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/loai-bao-tri/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/loai-bao-tri/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/baotri/loai-bao-tri/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/bo-phan/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/bo-phan/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/bo-phan/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/bo-phan/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/bo-phan/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/bo-phan/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/bo-phan/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/default/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/default/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/doi-tac/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/doi-tac/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/doi-tac/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/doi-tac/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/doi-tac/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/doi-tac/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/doi-tac/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhan-vien/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhan-vien/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhan-vien/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhan-vien/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhan-vien/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhan-vien/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhan-vien/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhom-doi-tac/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhom-doi-tac/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhom-doi-tac/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhom-doi-tac/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhom-doi-tac/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhom-doi-tac/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/bophan/nhom-doi-tac/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/cache/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/cache/flush', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/cache/flush-all', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/cache/flush-schema', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/cache/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/dungchung/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/default/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/default/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/create-outer', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/delete-outer', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/update-outer', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/hinh-anh/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/history/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/history/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/history/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/history/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/history/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/history/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/history/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/import/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/import/import', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/import/upload', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/create-outer', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/delete-outer', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/update-outer', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/dungchung/tai-lieu/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/fixture/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/fixture/load', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/fixture/unload', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/hello/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/hello/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/help/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/help/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/help/list', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/help/list-action-options', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/help/usage', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/default/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/default/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/depdrop/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/depdrop/get-nhan-vien', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/dm-vat-tu/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/dm-vat-tu/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/dm-vat-tu/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/dm-vat-tu/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/dm-vat-tu/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/dm-vat-tu/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/dm-vat-tu/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/kho/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/kho/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/kho/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/kho/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/kho/get-vat-tu-list', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/kho/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/kho/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/kho/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/kholuutru/lich-su-vat-tu/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/lich-su-vat-tu/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/lich-su-vat-tu/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/lich-su-vat-tu/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/lich-su-vat-tu/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/lich-su-vat-tu/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/kholuutru/lich-su-vat-tu/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/message/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/message/config', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/message/config-template', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/message/extract', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/down', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/fresh', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/history', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/mark', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/new', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/redo', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/to', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/migrate/up', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/serve/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/serve/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/bao-gia-sua-chua/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/bao-gia-sua-chua/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/bao-gia-sua-chua/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/bao-gia-sua-chua/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/bao-gia-sua-chua/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/bao-gia-sua-chua/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/bao-gia-sua-chua/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/ct-bao-gia-sua-chua/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/ct-bao-gia-sua-chua/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/ct-bao-gia-sua-chua/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/ct-bao-gia-sua-chua/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/ct-bao-gia-sua-chua/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/ct-bao-gia-sua-chua/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/ct-bao-gia-sua-chua/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/default/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/default/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/dm-tt-sua-chua/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/dm-tt-sua-chua/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/dm-tt-sua-chua/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/dm-tt-sua-chua/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/dm-tt-sua-chua/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/dm-tt-sua-chua/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/dm-tt-sua-chua/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua-vat-tu/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua-vat-tu/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua-vat-tu/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua-vat-tu/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua-vat-tu/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua-vat-tu/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua-vat-tu/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/chi-tiet-phieu-sua-chua', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/print-view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/suachua/phieu-sua-chua/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/default/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/default/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/gui-yeu-cau-van-hanh/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/gui-yeu-cau-van-hanh/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/gui-yeu-cau-van-hanh/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/gui-yeu-cau-van-hanh/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/gui-yeu-cau-van-hanh/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/gui-yeu-cau-van-hanh/send-request', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/gui-yeu-cau-van-hanh/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/gui-yeu-cau-van-hanh/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/he-thong/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/he-thong/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/he-thong/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/he-thong/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/he-thong/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/he-thong/list-thiet-bi', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/he-thong/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/he-thong/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/loai-thiet-bi/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/loai-thiet-bi/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/loai-thiet-bi/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/loai-thiet-bi/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/loai-thiet-bi/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/loai-thiet-bi/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/loai-thiet-bi/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/phe-duyet-yeu-cau-van-hanh/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/phe-duyet-yeu-cau-van-hanh/approve', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/phe-duyet-yeu-cau-van-hanh/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/phe-duyet-yeu-cau-van-hanh/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/phe-duyet-yeu-cau-van-hanh/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/phe-duyet-yeu-cau-van-hanh/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/phe-duyet-yeu-cau-van-hanh/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/qr/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/qr/in-loai', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/qr/in-qrs', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/copy', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/thiet-bi/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/index-bo-phan', 3, NULL, NULL, NULL, 1691567228, 1691567228, NULL),
('/taisan/thiet-bi/index-user', 3, NULL, NULL, NULL, 1691567228, 1691567228, NULL),
('/taisan/thiet-bi/qr-scan', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/thiet-bi/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/vi-tri/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/vi-tri/bulkdelete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/vi-tri/create', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/vi-tri/delete', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/vi-tri/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/vi-tri/update', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/vi-tri/view', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/taisan/xuat-yeu-cau-van-hanh/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/xuat-yeu-cau-van-hanh/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/xuat-yeu-cau-van-hanh/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/xuat-yeu-cau-van-hanh/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/xuat-yeu-cau-van-hanh/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/xuat-yeu-cau-van-hanh/operate', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/xuat-yeu-cau-van-hanh/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/xuat-yeu-cau-van-hanh/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh-ct/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh-ct/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh-ct/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh-ct/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh-ct/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh-ct/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh-ct/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh/*', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh/bulkdelete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh/create', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh/delete', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh/index', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh/update', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/taisan/yeu-cau-van-hanh/view', 3, NULL, NULL, NULL, 1717077553, 1717077553, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user/*', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/*', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/captcha', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/change-own-password', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/confirm-email', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/login', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/logout', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/password-recovery', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/auth/registration', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/default/*', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/default/index', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/giao-dien/*', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/user/giao-dien/index', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/user/user-ajax/*', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-ajax/bulkdelete', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-ajax/change-password', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/user/user-ajax/create', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-ajax/delete', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-ajax/index', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-ajax/update', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-ajax/view', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-permission/*', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-permission/set', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user-permission/set-roles', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/*', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/activity', 3, NULL, NULL, NULL, 1691110097, 1691110097, NULL),
('/user/user/bulk-activate', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/bulk-deactivate', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/bulk-delete', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/change-password', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/create', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/delete', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/grid-page-size', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/grid-sort', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/index', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/toggle-attribute', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/update', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('/user/user/view', 3, NULL, NULL, NULL, 1689123866, 1689123866, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1689001074, 1689001074, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('macDinh', 1, 'Mặc định cho tài khoản', NULL, NULL, 1691653271, 1691653271, NULL),
('nDuyetBaoGiaSuaChua', 1, 'Duyệt báo giá sửa chữa', NULL, NULL, 1717077553, 1717077553, NULL),
('nQuanLyBoPhan', 1, 'Quản lý Phòng ban - Bộ phận', NULL, NULL, 1691483880, 1691483880, NULL),
('nQuanLyDanhMuc', 1, 'Quản lý danh mục', NULL, NULL, 1691483908, 1691483908, NULL),
('nQuanLyDoiTac', 1, 'Quản lý đối tác', NULL, NULL, 1691483922, 1691483922, NULL),
('nQuanLyHeThongThietBi', 1, 'Quản lý hệ thống thiết bị', NULL, NULL, 1691483941, 1691483941, NULL),
('nQuanLyKho', 1, 'Quản lý kho lưu trữ', NULL, NULL, 1691483957, 1691483957, NULL),
('nQuanLyLoaiThietBi', 1, 'Quản lý loại thiết bị', NULL, NULL, 1691483978, 1691483978, NULL),
('nQuanLyNhanVien', 1, 'Quản lý nhân viên', NULL, NULL, 1691483998, 1691483998, NULL),
('nQuanLyPhieuSuaChua', 1, 'Quản lý phiếu sửa chữa', NULL, NULL, 1717077553, 1717077553, NULL),
('nQuanLyTaiSan', 1, 'Quản lý tài sản', NULL, NULL, 1691484016, 1691484016, NULL),
('nQuanLyVatTuKho', 1, 'Quản lý vật tư kho', NULL, NULL, 1717077553, 1717077553, NULL),
('nQuanLyViTri', 1, 'Quản lý vị trí', NULL, NULL, 1691484042, 1691484042, NULL),
('nQuanTriTaiKhoan', 1, 'Quản trị tài khoản người dùng', NULL, NULL, 1691483835, 1691483835, NULL),
('nXemTatCa', 1, 'Quyền xem', NULL, NULL, 1691484173, 1691484173, NULL),
('qDanhMucNhomDoiTac', 2, 'Quản lý danh mục nhóm đối tác', NULL, NULL, 1691481882, 1691481882, 'quanLyDanhMuc'),
('qDanhSachBoPhan', 2, 'Xem danh sách bộ phận', NULL, NULL, 1691420418, 1691420430, 'quanLyBoPhan'),
('qDanhSachDoiTac', 2, 'Xem danh sách đối tác', NULL, NULL, 1691480297, 1691480297, 'quanLyDoiTac'),
('qDanhSachHeThongThietBi', 2, 'Xem danh sách hệ thống thiết bị', NULL, NULL, 1691482349, 1691482349, 'quanLyHeThongThietBi'),
('qDanhSachKho', 2, 'Xem danh sách Kho lưu trữ', NULL, NULL, 1691482033, 1691482033, 'quanLyKhoLuuTru'),
('qDanhSachLoaiThietBi', 2, 'Xem danh sách loại thiết bị', NULL, NULL, 1691482755, 1691482755, 'quanLyLoaiThietBi'),
('qDanhSachNhanVien', 2, 'Xem danh sách nhân viên', NULL, NULL, 1691481320, 1691481320, 'quanLyNhanVien'),
('qDanhSachTaiKhoan', 2, 'Xem danh sách tài khoản', NULL, NULL, 1691399023, 1691399298, 'accountsManage'),
('qDanhSachTaiSan', 2, 'Xem danh sách tài sản - thiết bị', NULL, NULL, 1691375126, 1691399310, 'quanLyTaiSan'),
('qDanhSachViTri', 2, 'Xem danh sách vị trí', NULL, NULL, 1691400832, 1691400832, 'quanLyViTri'),
('qDuyetBaoGiaSuaChua', 2, 'Duyệt báo giá sửa chữa', NULL, NULL, 1717077551, 1717077551, 'quanLyPhieuSuaChua'),
('qGiaoDienThietBi', 2, 'Tùy chỉnh giao diện cho thiết bị cá nhân', NULL, NULL, 1691399872, 1691399872, 'userCommonPermissions'),
('qInQrTaiSan', 2, 'In QR tài sản - thiết bị', NULL, NULL, 1691375622, 1691399273, 'quanLyTaiSan'),
('qPhanQuyenTaiKhoan', 2, 'Phân quyền cho tài khoản', NULL, NULL, 1691399576, 1691399576, 'accountsManage'),
('qQuanLyTaiSanBoPhan', 2, 'Quản lý tài sản của Phòng ban - Bộ phận', NULL, NULL, 1691567345, 1691567345, 'quanLyTaiSan'),
('qQuanLyTaiSanCaNhan', 2, 'Quản lý tài sản được giao', NULL, NULL, 1691567465, 1691567465, 'userCommonPermissions'),
('qScanQrTaiSan', 2, 'Scan QR xem tài sản - thiết bị', NULL, NULL, 1691375522, 1691399264, 'quanLyTaiSan'),
('qSuaBaoGiaSuaChua', 2, 'Sửa báo giá sửa chữa', NULL, NULL, 1717077551, 1717077551, 'quanLyPhieuSuaChua'),
('qSuaBoPhan', 2, 'Sửa thông tin bộ phận', NULL, NULL, 1691420634, 1691420634, 'quanLyBoPhan'),
('qSuaDoiTac', 2, 'Sửa thông tin đối tác', NULL, NULL, 1691480405, 1691480405, 'quanLyDoiTac'),
('qSuaHeThongThietBi', 2, 'Sửa thông tin hệ thống thiết bị', NULL, NULL, 1691482549, 1691482549, 'quanLyHeThongThietBi'),
('qSuaKho', 2, 'Sửa thông tin kho lưu trữ', NULL, NULL, 1691482132, 1691482132, 'quanLyKhoLuuTru'),
('qSuaLoaiThietBi', 2, 'Sửa loại thiết bị', NULL, NULL, 1691482839, 1691482839, 'quanLyLoaiThietBi'),
('qSuaNhanVien', 2, 'Sửa thông tin nhân viên', NULL, NULL, 1691481669, 1691481669, 'quanLyNhanVien'),
('qSuaPhieuSuaChua', 2, 'Sửa phiếu sửa chữa', NULL, NULL, 1717077551, 1717077551, 'quanLyPhieuSuaChua'),
('qSuaTaiKhoan', 2, 'Sửa tài khoản', NULL, NULL, 1689124200, 1691399360, 'accountsManage'),
('qSuaTaiSan', 2, 'Sửa thông tin tài sản - thiết bị', NULL, NULL, 1691375293, 1691399239, 'quanLyTaiSan'),
('qSuaVatTu', 2, 'Cập nhật vật tư kho', NULL, NULL, 1717077551, 1717077551, 'quanLyDmVatTu'),
('qSuaViTri', 2, 'Sửa vị trí', NULL, NULL, 1691401058, 1691401058, 'quanLyViTri'),
('qThayDoiMatKhauCaNhan', 2, 'Thay đổi mật khẩu cá nhân', NULL, NULL, 1691109892, 1691399740, 'userCommonPermissions'),
('qThemBoPhan', 2, 'Thêm bộ phận', NULL, NULL, 1691420545, 1691420608, 'quanLyBoPhan'),
('qThemDoiTac', 2, 'Thêm mới đối tác', NULL, NULL, 1691480380, 1691480380, 'quanLyDoiTac'),
('qThemHeThongThietBi', 2, 'Thêm hệ thống thiết bị', NULL, NULL, 1691482620, 1691482620, 'quanLyHeThongThietBi'),
('qThemKho', 2, 'Thêm thông tin kho lưu trữ', NULL, NULL, 1691482097, 1691482097, 'quanLyKhoLuuTru'),
('qThemLoaiThietBi', 2, 'Thêm loại thiết bị', NULL, NULL, 1691482811, 1691482811, 'quanLyLoaiThietBi'),
('qThemNhanVien', 2, 'Thêm nhân viên', NULL, NULL, 1691481648, 1691481648, 'quanLyNhanVien'),
('qThemPhieuSuaChua', 2, 'Thêm phiếu sửa chữa', NULL, NULL, 1717077551, 1717077551, 'quanLyPhieuSuaChua'),
('qThemTaiKhoan', 2, 'Thêm tài khoản', NULL, NULL, 1689123863, 1691399351, 'accountsManage'),
('qThemTaiSan', 2, 'Thêm mới tài sản', NULL, NULL, 1691375384, 1691399247, 'quanLyTaiSan'),
('qThemVatTu', 2, 'Thêm vật tư kho', NULL, NULL, 1717077551, 1717077551, 'quanLyDmVatTu'),
('qThemViTri', 2, 'Thêm vị trí', NULL, NULL, 1691110325, 1691400562, 'quanLyViTri'),
('qXemBoPhan', 2, 'Xem thông tin bộ phận', NULL, NULL, 1691420483, 1691420483, 'quanLyBoPhan'),
('qXemDanhSachPhieuSuaChua', 2, 'Xem danh sách phiếu sửa chữa', NULL, NULL, 1717077551, 1717077551, 'quanLyPhieuSuaChua'),
('qXemDanhSachVatTu', 2, 'Quyền xem danh sách vật tư', NULL, NULL, 1717077551, 1717077551, 'quanLyDmVatTu'),
('qXemDashboard', 2, 'Truy cập Dashboard', NULL, NULL, 1691399814, 1691399814, 'userCommonPermissions'),
('qXemDoiTac', 2, 'Xem thông tin đối tác', NULL, NULL, 1691480321, 1691480321, 'quanLyDoiTac'),
('qXemHeThongThietBi', 2, 'Xem thông tin hệ thống thiết bị', NULL, NULL, 1691482522, 1691482522, 'quanLyHeThongThietBi'),
('qXemHoatDongCaNhan', 2, 'Xem thông tin lịch sử hoạt động của cá nhân', NULL, NULL, 1691109981, 1691399711, 'userCommonPermissions'),
('qXemKho', 2, 'Xem thông tin kho lưu trữ', NULL, NULL, 1691482067, 1691482067, 'quanLyKhoLuuTru'),
('qXemLoaiThietBi', 2, 'Xem thông tin loại thiết bị', NULL, NULL, 1691482782, 1691482782, 'quanLyLoaiThietBi'),
('qXemNhanVien', 2, 'Xem thông tin nhân viên', NULL, NULL, 1691481358, 1691481358, 'quanLyNhanVien'),
('qXemTaiKhoan', 2, 'Xem tài khoản', NULL, NULL, 1689124249, 1691399377, 'accountsManage'),
('qXemTaiSan', 2, 'Xem Thông tin chi tiết tài sản - thiết bị', NULL, NULL, 1691375224, 1691399225, 'quanLyTaiSan'),
('qXemViTri', 2, 'Xem thông tin vị trí', NULL, NULL, 1691400883, 1691400883, 'quanLyViTri'),
('qXoaBoPhan', 2, 'Xóa bộ phận', NULL, NULL, 1691420667, 1691420667, 'quanLyBoPhan'),
('qXoaDoiTac', 2, 'Xóa đối tác', NULL, NULL, 1691480428, 1691480428, 'quanLyDoiTac'),
('qXoaHeThongThietBi', 2, 'Xóa hệ thống thiết bị', NULL, NULL, 1691482576, 1691482576, 'quanLyHeThongThietBi'),
('qXoaKho', 2, 'Xóa kho lưu trữ', NULL, NULL, 1691482161, 1691482161, 'quanLyKhoLuuTru'),
('qXoaLoaiThietBi', 2, 'Xóa loại thiết bị', NULL, NULL, 1691482867, 1691482867, 'quanLyLoaiThietBi'),
('qXoaNhanVien', 2, 'Xóa nhân viên', NULL, NULL, 1691481693, 1691481693, 'quanLyNhanVien'),
('qXoaPhieuSuaChua', 2, 'Xóa phiếu sửa chữa', NULL, NULL, 1717077551, 1717077551, 'quanLyPhieuSuaChua'),
('qXoaTaiKhoan', 2, 'Xóa tài khoản', NULL, NULL, 1689124228, 1691399369, 'accountsManage'),
('qXoaTaiSan', 2, 'Xóa tài sản - thiết bị', NULL, NULL, 1691375438, 1691399255, 'quanLyTaiSan'),
('qXoaVatTu', 2, 'Xóa vật tư kho', NULL, NULL, 1717077551, 1717077551, 'quanLyDmVatTu'),
('qXoaViTri', 2, 'Xóa vị trí', NULL, NULL, 1691401098, 1691401098, 'quanLyViTri'),
('user_1_', 1, 'Quyền tùy chỉnh cho user superadmin', NULL, NULL, 1691396390, 1691396390, NULL),
('user_20_', 1, 'Quyền tùy chỉnh cho user tyan6', NULL, NULL, 1691975112, 1691975112, NULL),
('user_2_', 1, 'Quyền tùy chỉnh cho user u001', NULL, NULL, 1691485109, 1691485109, NULL),
('user_4_', 1, 'Quyền tùy chỉnh cho user user003', NULL, NULL, 1691396411, 1691396411, NULL),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1689001075, 1689001075, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('qXoaBoPhan', '/bophan/bo-phan/bulkdelete'),
('qThemBoPhan', '/bophan/bo-phan/create'),
('qXoaBoPhan', '/bophan/bo-phan/delete'),
('qDanhSachBoPhan', '/bophan/bo-phan/index'),
('qSuaBoPhan', '/bophan/bo-phan/update'),
('qXemBoPhan', '/bophan/bo-phan/view'),
('qXoaDoiTac', '/bophan/doi-tac/bulkdelete'),
('qThemDoiTac', '/bophan/doi-tac/create'),
('qXoaDoiTac', '/bophan/doi-tac/delete'),
('qDanhSachDoiTac', '/bophan/doi-tac/index'),
('qSuaDoiTac', '/bophan/doi-tac/update'),
('qXemDoiTac', '/bophan/doi-tac/view'),
('qXoaNhanVien', '/bophan/nhan-vien/bulkdelete'),
('qThemNhanVien', '/bophan/nhan-vien/create'),
('qXoaNhanVien', '/bophan/nhan-vien/delete'),
('qDanhSachNhanVien', '/bophan/nhan-vien/index'),
('qSuaNhanVien', '/bophan/nhan-vien/update'),
('qXemNhanVien', '/bophan/nhan-vien/view'),
('qDanhMucNhomDoiTac', '/bophan/nhom-doi-tac/*'),
('qSuaPhieuSuaChua', '/dungchung/hinh-anh/create-outer'),
('qSuaPhieuSuaChua', '/dungchung/hinh-anh/delete-outer'),
('qSuaPhieuSuaChua', '/dungchung/hinh-anh/update-outer'),
('qSuaPhieuSuaChua', '/dungchung/tai-lieu/create-outer'),
('qSuaPhieuSuaChua', '/dungchung/tai-lieu/delete-outer'),
('qSuaPhieuSuaChua', '/dungchung/tai-lieu/update-outer'),
('qDanhSachKho', '/kholuutru/depdrop/get-nhan-vien'),
('qSuaKho', '/kholuutru/depdrop/get-nhan-vien'),
('qThemKho', '/kholuutru/depdrop/get-nhan-vien'),
('qXemKho', '/kholuutru/depdrop/get-nhan-vien'),
('qThemVatTu', '/kholuutru/dm-vat-tu/create'),
('qXoaVatTu', '/kholuutru/dm-vat-tu/delete'),
('qXemDanhSachVatTu', '/kholuutru/dm-vat-tu/index'),
('qSuaVatTu', '/kholuutru/dm-vat-tu/update'),
('qXoaKho', '/kholuutru/kho/bulkdelete'),
('qThemKho', '/kholuutru/kho/create'),
('qXoaKho', '/kholuutru/kho/delete'),
('qSuaPhieuSuaChua', '/kholuutru/kho/get-vat-tu-list'),
('qDanhSachKho', '/kholuutru/kho/index'),
('qSuaKho', '/kholuutru/kho/update'),
('qXemKho', '/kholuutru/kho/view'),
('qDuyetBaoGiaSuaChua', '/suachua/bao-gia-sua-chua/index'),
('qXemDanhSachPhieuSuaChua', '/suachua/bao-gia-sua-chua/index'),
('qDuyetBaoGiaSuaChua', '/suachua/bao-gia-sua-chua/update'),
('qSuaBaoGiaSuaChua', '/suachua/bao-gia-sua-chua/update'),
('qDuyetBaoGiaSuaChua', '/suachua/bao-gia-sua-chua/view'),
('qXemDanhSachPhieuSuaChua', '/suachua/bao-gia-sua-chua/view'),
('qSuaPhieuSuaChua', '/suachua/ct-bao-gia-sua-chua/create'),
('qSuaPhieuSuaChua', '/suachua/ct-bao-gia-sua-chua/delete'),
('qSuaPhieuSuaChua', '/suachua/ct-bao-gia-sua-chua/index'),
('qSuaPhieuSuaChua', '/suachua/ct-bao-gia-sua-chua/update'),
('qSuaPhieuSuaChua', '/suachua/phieu-sua-chua-vat-tu/create'),
('qSuaPhieuSuaChua', '/suachua/phieu-sua-chua-vat-tu/delete'),
('qSuaPhieuSuaChua', '/suachua/phieu-sua-chua-vat-tu/index'),
('qSuaPhieuSuaChua', '/suachua/phieu-sua-chua-vat-tu/update'),
('qSuaPhieuSuaChua', '/suachua/phieu-sua-chua-vat-tu/view'),
('qSuaPhieuSuaChua', '/suachua/phieu-sua-chua/chi-tiet-phieu-sua-chua'),
('qThemPhieuSuaChua', '/suachua/phieu-sua-chua/create'),
('qXoaPhieuSuaChua', '/suachua/phieu-sua-chua/delete'),
('qXemDanhSachPhieuSuaChua', '/suachua/phieu-sua-chua/index'),
('qSuaPhieuSuaChua', '/suachua/phieu-sua-chua/update'),
('qXoaHeThongThietBi', '/taisan/he-thong/bulkdelete'),
('qThemHeThongThietBi', '/taisan/he-thong/create'),
('qXoaHeThongThietBi', '/taisan/he-thong/delete'),
('qDanhSachHeThongThietBi', '/taisan/he-thong/index'),
('qSuaHeThongThietBi', '/taisan/he-thong/update'),
('qXemHeThongThietBi', '/taisan/he-thong/view'),
('qXoaLoaiThietBi', '/taisan/loai-thiet-bi/bulkdelete'),
('qThemLoaiThietBi', '/taisan/loai-thiet-bi/create'),
('qXoaLoaiThietBi', '/taisan/loai-thiet-bi/delete'),
('qDanhSachLoaiThietBi', '/taisan/loai-thiet-bi/index'),
('qSuaLoaiThietBi', '/taisan/loai-thiet-bi/update'),
('qXemLoaiThietBi', '/taisan/loai-thiet-bi/view'),
('qInQrTaiSan', '/taisan/qr/in-loai'),
('qInQrTaiSan', '/taisan/qr/in-qrs'),
('qXoaTaiSan', '/taisan/thiet-bi/bulkdelete'),
('qThemTaiSan', '/taisan/thiet-bi/create'),
('qXoaTaiSan', '/taisan/thiet-bi/delete'),
('qDanhSachTaiSan', '/taisan/thiet-bi/index'),
('qQuanLyTaiSanBoPhan', '/taisan/thiet-bi/index-bo-phan'),
('qQuanLyTaiSanCaNhan', '/taisan/thiet-bi/index-user'),
('qScanQrTaiSan', '/taisan/thiet-bi/qr-scan'),
('qSuaTaiSan', '/taisan/thiet-bi/update'),
('qXemTaiSan', '/taisan/thiet-bi/view'),
('qXoaViTri', '/taisan/vi-tri/bulkdelete'),
('qThemViTri', '/taisan/vi-tri/create'),
('qXoaViTri', '/taisan/vi-tri/delete'),
('qDanhSachViTri', '/taisan/vi-tri/index'),
('qSuaViTri', '/taisan/vi-tri/update'),
('qXemViTri', '/taisan/vi-tri/view'),
('qThayDoiMatKhauCaNhan', '/user/auth/change-own-password'),
('qXemDashboard', '/user/default/index'),
('qGiaoDienThietBi', '/user/giao-dien/index'),
('qXoaTaiKhoan', '/user/user-ajax/bulkdelete'),
('qThemTaiKhoan', '/user/user-ajax/create'),
('qXoaTaiKhoan', '/user/user-ajax/delete'),
('qDanhSachTaiKhoan', '/user/user-ajax/index'),
('qXemTaiKhoan', '/user/user-ajax/index'),
('qSuaTaiKhoan', '/user/user-ajax/update'),
('qXemTaiKhoan', '/user/user-ajax/view'),
('qPhanQuyenTaiKhoan', '/user/user-permission/set'),
('qPhanQuyenTaiKhoan', '/user/user-permission/set-roles'),
('qXemHoatDongCaNhan', '/user/user/activity'),
('nQuanLyDanhMuc', 'qDanhMucNhomDoiTac'),
('nQuanLyBoPhan', 'qDanhSachBoPhan'),
('nXemTatCa', 'qDanhSachBoPhan'),
('nQuanLyDoiTac', 'qDanhSachDoiTac'),
('nXemTatCa', 'qDanhSachDoiTac'),
('nQuanLyHeThongThietBi', 'qDanhSachHeThongThietBi'),
('nXemTatCa', 'qDanhSachHeThongThietBi'),
('nQuanLyKho', 'qDanhSachKho'),
('nXemTatCa', 'qDanhSachKho'),
('nQuanLyLoaiThietBi', 'qDanhSachLoaiThietBi'),
('nXemTatCa', 'qDanhSachLoaiThietBi'),
('nQuanLyNhanVien', 'qDanhSachNhanVien'),
('nXemTatCa', 'qDanhSachNhanVien'),
('nQuanTriTaiKhoan', 'qDanhSachTaiKhoan'),
('nXemTatCa', 'qDanhSachTaiKhoan'),
('nQuanLyTaiSan', 'qDanhSachTaiSan'),
('nXemTatCa', 'qDanhSachTaiSan'),
('nQuanLyViTri', 'qDanhSachViTri'),
('nXemTatCa', 'qDanhSachViTri'),
('nDuyetBaoGiaSuaChua', 'qDuyetBaoGiaSuaChua'),
('user_2_', 'qDuyetBaoGiaSuaChua'),
('macDinh', 'qGiaoDienThietBi'),
('nQuanLyTaiSan', 'qInQrTaiSan'),
('nQuanTriTaiKhoan', 'qPhanQuyenTaiKhoan'),
('macDinh', 'qQuanLyTaiSanCaNhan'),
('nQuanLyTaiSan', 'qScanQrTaiSan'),
('nXemTatCa', 'qScanQrTaiSan'),
('nQuanLyPhieuSuaChua', 'qSuaBaoGiaSuaChua'),
('nQuanLyBoPhan', 'qSuaBoPhan'),
('nQuanLyDoiTac', 'qSuaDoiTac'),
('nQuanLyHeThongThietBi', 'qSuaHeThongThietBi'),
('nQuanLyKho', 'qSuaKho'),
('nQuanLyLoaiThietBi', 'qSuaLoaiThietBi'),
('nQuanLyNhanVien', 'qSuaNhanVien'),
('nQuanLyPhieuSuaChua', 'qSuaPhieuSuaChua'),
('nQuanTriTaiKhoan', 'qSuaTaiKhoan'),
('nQuanLyTaiSan', 'qSuaTaiSan'),
('nQuanLyVatTuKho', 'qSuaVatTu'),
('nQuanLyViTri', 'qSuaViTri'),
('macDinh', 'qThayDoiMatKhauCaNhan'),
('nQuanLyBoPhan', 'qThemBoPhan'),
('nQuanLyDoiTac', 'qThemDoiTac'),
('nQuanLyHeThongThietBi', 'qThemHeThongThietBi'),
('nQuanLyKho', 'qThemKho'),
('nQuanLyLoaiThietBi', 'qThemLoaiThietBi'),
('nQuanLyNhanVien', 'qThemNhanVien'),
('nQuanLyPhieuSuaChua', 'qThemPhieuSuaChua'),
('nQuanTriTaiKhoan', 'qThemTaiKhoan'),
('nQuanLyTaiSan', 'qThemTaiSan'),
('nQuanLyVatTuKho', 'qThemVatTu'),
('nQuanLyViTri', 'qThemViTri'),
('nQuanLyBoPhan', 'qXemBoPhan'),
('nXemTatCa', 'qXemBoPhan'),
('nQuanLyPhieuSuaChua', 'qXemDanhSachPhieuSuaChua'),
('nQuanLyVatTuKho', 'qXemDanhSachVatTu'),
('macDinh', 'qXemDashboard'),
('nQuanLyDoiTac', 'qXemDoiTac'),
('nXemTatCa', 'qXemDoiTac'),
('nQuanLyHeThongThietBi', 'qXemHeThongThietBi'),
('nXemTatCa', 'qXemHeThongThietBi'),
('macDinh', 'qXemHoatDongCaNhan'),
('nQuanLyKho', 'qXemKho'),
('nXemTatCa', 'qXemKho'),
('nQuanLyLoaiThietBi', 'qXemLoaiThietBi'),
('nXemTatCa', 'qXemLoaiThietBi'),
('nQuanLyNhanVien', 'qXemNhanVien'),
('nXemTatCa', 'qXemNhanVien'),
('nQuanTriTaiKhoan', 'qXemTaiKhoan'),
('nXemTatCa', 'qXemTaiKhoan'),
('qSuaTaiKhoan', 'qXemTaiKhoan'),
('qThemTaiKhoan', 'qXemTaiKhoan'),
('qXoaTaiKhoan', 'qXemTaiKhoan'),
('nQuanLyTaiSan', 'qXemTaiSan'),
('nXemTatCa', 'qXemTaiSan'),
('qInQrTaiSan', 'qXemTaiSan'),
('qScanQrTaiSan', 'qXemTaiSan'),
('nQuanLyViTri', 'qXemViTri'),
('nXemTatCa', 'qXemViTri'),
('nQuanLyBoPhan', 'qXoaBoPhan'),
('nQuanLyDoiTac', 'qXoaDoiTac'),
('nQuanLyHeThongThietBi', 'qXoaHeThongThietBi'),
('nQuanLyKho', 'qXoaKho'),
('nQuanLyLoaiThietBi', 'qXoaLoaiThietBi'),
('nQuanLyNhanVien', 'qXoaNhanVien'),
('nQuanLyPhieuSuaChua', 'qXoaPhieuSuaChua'),
('nQuanTriTaiKhoan', 'qXoaTaiKhoan'),
('nQuanLyTaiSan', 'qXoaTaiSan'),
('nQuanLyVatTuKho', 'qXoaVatTu'),
('nQuanLyViTri', 'qXoaViTri'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('accountsManage', 'Quản trị tài khoản người dùng', NULL, NULL),
('quanLyBoPhan', 'Quản lý Phòng ban - Bộ phận', NULL, NULL),
('quanLyDanhMuc', 'Quản lý danh mục', NULL, NULL),
('quanLyDmVatTu', 'Quản lý danh mục vật tư kho', 1717077551, 1717077551),
('quanLyDoiTac', 'Quản lý đối tác', NULL, NULL),
('quanLyHeThongThietBi', 'Quản lý hệ thống thiết bị', NULL, NULL),
('quanLyKhoLuuTru', 'Quản lý kho lưu trữ', NULL, NULL),
('quanLyLoaiThietBi', 'Quản lý loại thiết bị', NULL, NULL),
('quanLyNhanVien', 'Quản lý nhân viên', NULL, NULL),
('quanLyPhieuSuaChua', 'Quản lý phiếu sửa chữa', 1717077551, 1717077551),
('quanLyTaiSan', 'Quản lý tài sản', NULL, NULL),
('quanLyViTri', 'Quản lý vị trí', NULL, NULL),
('userCommonPermissions', 'Quyền cho tài khoản', 1689001075, 1689001075),
('userManagement', 'User management', 1689001075, 1689001075);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1715086910),
('m140608_173539_create_user_table', 1715087511),
('m140611_133903_init_rbac', 1715087511),
('m140808_073114_create_auth_item_group_table', 1715087511),
('m140809_072112_insert_superadmin_to_user', 1715087512),
('m140809_073114_insert_common_permisison_to_auth_item', 1715087513),
('m141023_141535_create_user_visit_log', 1715087513),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1715087513),
('m141121_194858_split_browser_and_os_column', 1715087513),
('m141201_220516_add_email_and_email_confirmed_to_user', 1715087514),
('m141207_001649_create_basic_user_permissions', 1715087515),
('m240425_125048_create_table_ts_bo_phan', 1715086916),
('m240425_125150_create_table_ts_nhom_doi_tac', 1715087124),
('m240425_125859_create_table_ts_doi_tac', 1715087124),
('m240425_130703_create_table_ts_he_thong', 1715087124),
('m240425_131223_create_table_ts_hinh_anh', 1715087124),
('m240426_071111_create_table_ts_history', 1715087124),
('m240426_071910_create_table_ts_loai_bao_tri', 1715087124),
('m240426_072759_create_table_ts_loai_thiet_bi', 1715087125),
('m240426_073138_create_table_ts_lop_hu_hong', 1715087125),
('m240426_073957_create_table_ts_tai_lieu', 1715087125),
('m240426_074321_create_table_ts_nhan_vien', 1715087125),
('m240426_075023_create_table_ts_thiet_bi', 1715087125),
('m240426_081552_create_table_ts_vi_tri', 1715087125),
('m240507_125221_create_table_ts_kho_luu_tru', 1715087125),
('m240507_125934_create_table_ts_ke_hoach_bao_tri', 1715090877),
('m240507_131512_create_table_ts_nhan_vien_kho', 1715090877),
('m240507_132108_create_table_ts_dm_tt_sua_chua', 1716786238),
('m240507_133250_create_table_ts_phieu_sua_chua', 1716786238),
('m240507_133739_create_table_ts_bao_gia_sua_chua', 1716786238),
('m240507_134644_create_table_ts_ct_bao_gia_sua_chua', 1716786238),
('m240507_135522_create_table_ts_dm_vat_tu', 1716786238),
('m240507_140256_create_table_ts_phieu_sua_chua_vat_tu', 1716786238),
('m240514_164146_create_table_ts_yeu_cau_van_hanh', 1717077550),
('m240521_134158_create_table_ts_yeu_cau_van_hanh_ct', 1717077550),
('m240524_081934_create_ts_lich_su_vat_tu_table', 1716786239),
('m240525_133847_add_hang_san_xuat_to_ts_dm_vat_tu_table', 1716786239),
('m240525_151020_add_dia_chi_to_ts_phieu_sua_chua_table', 1716786239),
('m240528_130019_insert_auth_item_group_data', 1717077551),
('m240528_132744_insert_auth_item_data', 1717077551),
('m240528_140354_insert_auth_item_child_data', 1717077553),
('m240528_150329_insert_role_data', 1717077553),
('m240605_033243_create_table_ts_phieu_bao_tri', 1719019289),
('m240625_125934_alter_table_ts_ke_hoach_bao_tri', 1719300928);

-- --------------------------------------------------------

--
-- Table structure for table `ts_bao_gia_sua_chua`
--

DROP TABLE IF EXISTS `ts_bao_gia_sua_chua`;
CREATE TABLE IF NOT EXISTS `ts_bao_gia_sua_chua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_phieu_sua_chua` int(11) NOT NULL,
  `so_bao_gia` int(11) DEFAULT '0',
  `flag_index` smallint(6) DEFAULT '0',
  `ngay_bao_gia` datetime DEFAULT NULL,
  `ngay_ket_thuc` datetime DEFAULT NULL,
  `ngay_gui_bg` datetime DEFAULT NULL,
  `trang_thai` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phi_linh_kien` decimal(10,2) DEFAULT NULL,
  `phi_khac` decimal(10,2) DEFAULT NULL,
  `tong_tien` decimal(10,2) DEFAULT NULL,
  `ghi_chu_bg1` text COLLATE utf8_unicode_ci,
  `ghi_chu_bg2` text COLLATE utf8_unicode_ci,
  `ngay_tao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nguoi_tao` int(11) DEFAULT NULL,
  `ngay_cap_nhat` timestamp NULL DEFAULT NULL,
  `nguoi_cap_nhat` int(11) DEFAULT NULL,
  `nguoi_duyet_bg` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-ts_bao_gia_sua_chua-id_phieu_sua_chua` (`id_phieu_sua_chua`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_bao_gia_sua_chua`
--

INSERT INTO `ts_bao_gia_sua_chua` (`id`, `id_phieu_sua_chua`, `so_bao_gia`, `flag_index`, `ngay_bao_gia`, `ngay_ket_thuc`, `ngay_gui_bg`, `trang_thai`, `phi_linh_kien`, `phi_khac`, `tong_tien`, `ghi_chu_bg1`, `ghi_chu_bg2`, `ngay_tao`, `nguoi_tao`, `ngay_cap_nhat`, `nguoi_cap_nhat`, `nguoi_duyet_bg`) VALUES
(1, 1, 1, 0, '2024-05-27 12:20:37', '2024-05-30 21:02:52', '2024-05-27 12:21:35', 'approved', NULL, '10000000.00', '10000000.00', 'nnn', 'ccxx', '2024-05-27 05:20:37', 1, NULL, NULL, 1),
(2, 2, 1, -1, '2024-05-27 12:28:17', '2024-05-30 21:03:08', '2024-05-30 21:01:29', 'rejected', '5000000.00', NULL, '5000000.00', 'v', '', '2024-05-27 05:28:17', 1, NULL, NULL, 1),
(3, 2, 2, 0, '2024-05-30 21:03:22', NULL, NULL, 'draft', '0.00', '0.00', '0.00', NULL, NULL, '2024-05-30 14:03:22', 1, NULL, NULL, NULL),
(4, 3, 1, 0, '2024-05-30 21:06:39', '2024-05-30 21:23:10', '2024-05-30 21:10:49', 'approved', NULL, '1000000.00', '1000000.00', 'sfsdfdsd', '', '2024-05-30 14:06:39', 1, NULL, NULL, 2),
(5, 4, 1, 0, '2024-05-30 21:31:52', NULL, NULL, 'draft', '0.00', '0.00', '0.00', NULL, NULL, '2024-05-30 14:31:52', 1, NULL, NULL, NULL),
(6, 5, 1, -1, '2024-05-30 21:34:33', '2024-05-30 21:35:30', '2024-05-30 21:35:12', 'rejected', '10000000.00', NULL, '10000000.00', 'sdfasfa', '', '2024-05-30 14:34:33', 1, NULL, NULL, 2),
(7, 5, 2, -1, '2024-05-30 21:35:35', '2024-05-30 21:41:41', '2024-05-30 21:37:25', 'rejected', NULL, '2000000.00', '2000000.00', 'fdafsf', '', '2024-05-30 14:35:35', 1, NULL, NULL, 2),
(8, 6, 1, 0, '2024-05-30 21:39:47', NULL, NULL, 'draft', '0.00', '0.00', '0.00', NULL, NULL, '2024-05-30 14:39:47', 1, NULL, NULL, NULL),
(9, 7, 1, 0, '2024-05-31 08:17:37', '2024-05-31 08:18:07', '2024-05-31 08:17:55', 'approved', NULL, '10000000.00', '10000000.00', 'dsd', '', '2024-05-31 01:17:37', 1, NULL, NULL, 1),
(10, 8, 1, 0, '2024-06-05 09:41:55', NULL, NULL, 'draft', '0.00', '0.00', '0.00', NULL, NULL, '2024-06-05 02:41:55', 1, '2024-06-05 02:41:55', 1, NULL),
(11, 9, 1, 0, '2024-06-05 09:53:11', '2024-06-05 09:53:44', '2024-06-05 09:53:17', 'approved', '0.00', '0.00', '0.00', 'ádad', '', '2024-06-05 02:53:11', 1, '2024-06-05 02:53:44', 1, 1),
(12, 10, 1, 0, '2024-06-05 10:20:10', NULL, NULL, 'draft', '0.00', '0.00', '0.00', NULL, NULL, '2024-06-05 03:20:10', 1, '2024-06-05 03:20:10', 1, NULL),
(13, 11, 1, 0, '2024-06-05 10:20:55', '2024-06-05 10:22:56', '2024-06-05 10:21:59', 'approved', '20000000.00', NULL, '20000000.00', 'hfhgdfhd', 'ffsdfsdf', '2024-06-05 03:20:55', 1, '2024-06-05 03:22:56', 1, 1),
(14, 12, 1, 0, '2024-06-05 10:22:29', NULL, NULL, 'draft', '0.00', '0.00', '0.00', NULL, NULL, '2024-06-05 03:22:29', 1, '2024-06-05 03:22:29', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ts_bo_phan`
--

DROP TABLE IF EXISTS `ts_bo_phan`;
CREATE TABLE IF NOT EXISTS `ts_bo_phan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_bo_phan` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_bo_phan` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `truc_thuoc` int(11) DEFAULT NULL,
  `la_dv_quan_ly` tinyint(1) DEFAULT NULL,
  `la_dv_su_dung` tinyint(1) DEFAULT NULL,
  `la_dv_bao_tri` tinyint(1) DEFAULT NULL,
  `la_dv_van_tai` tinyint(1) DEFAULT NULL,
  `la_dv_mua_hang` tinyint(1) DEFAULT NULL,
  `la_dv_quan_ly_kho` tinyint(1) DEFAULT NULL,
  `la_trung_tam_chi_phi` tinyint(1) DEFAULT NULL,
  `id_kho_vat_tu` int(11) DEFAULT NULL,
  `id_kho_phe_lieu` int(11) DEFAULT NULL,
  `id_kho_thanh_pham` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_bo_phan`
--

INSERT INTO `ts_bo_phan` (`id`, `ma_bo_phan`, `ten_bo_phan`, `truc_thuoc`, `la_dv_quan_ly`, `la_dv_su_dung`, `la_dv_bao_tri`, `la_dv_van_tai`, `la_dv_mua_hang`, `la_dv_quan_ly_kho`, `la_trung_tam_chi_phi`, `id_kho_vat_tu`, `id_kho_phe_lieu`, `id_kho_thanh_pham`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'BP001', 'Bộ phận A', 2, 1, 0, 0, 0, 1, 1, 0, 1, 1, 2, NULL, NULL),
(2, 'BP002', 'Phòng Las 1720', NULL, 1, 0, 1, 1, 0, 1, 0, NULL, NULL, 2, '2023-07-22 09:49:22', NULL),
(3, 'BP003', 'Trạm Bê tông Khu Công nghiệp', 0, 0, 1, 1, 0, 0, 0, 0, 2, 1, 2, '2023-07-22 10:36:35', 1),
(11, 'BP00112', 'Văn phòng', NULL, 1, 1, 0, 0, 1, 1, 1, NULL, NULL, NULL, '2023-07-31 09:07:37', 1),
(12, 'BP0021', 'Phòng Las', 0, 1, 1, 0, 0, 1, 1, 0, NULL, NULL, NULL, '2023-07-31 09:07:37', 1),
(13, 'BP0031', 'Phòng Kỹ thuật', 12, 1, 1, 1, 0, 1, 0, 0, NULL, NULL, NULL, '2023-07-31 09:07:37', 1),
(14, 'BP0041', 'Phòng IT', 12, 1, 1, 1, 0, 1, 0, 0, NULL, NULL, NULL, '2023-07-31 09:07:37', 1),
(15, 'BP005', 'Trạm Bê tông Khu Công Nghiệp', 11, 1, 1, 1, 0, 1, 1, 0, NULL, NULL, NULL, '2023-07-31 09:07:37', 1),
(16, 'BP006', 'Trạm Bê tông Duyên Hải', 11, 1, 1, 1, 0, 1, 1, 0, NULL, NULL, NULL, '2023-07-31 09:07:37', 1),
(17, 'BP007', 'Đội xe vận tải', NULL, 1, 1, 0, 1, 0, 0, 0, NULL, NULL, NULL, '2023-07-31 09:07:37', 1),
(18, 'BP0011', 'cfdsafsadfasf', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, '2024-04-24 12:38:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_ct_bao_gia_sua_chua`
--

DROP TABLE IF EXISTS `ts_ct_bao_gia_sua_chua`;
CREATE TABLE IF NOT EXISTS `ts_ct_bao_gia_sua_chua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_bao_gia` int(11) NOT NULL,
  `id_dm_bao_gia` int(11) DEFAULT NULL,
  `ten_danh_muc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `don_vi_tinh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` decimal(10,2) DEFAULT NULL,
  `thanh_tien` decimal(10,2) DEFAULT NULL,
  `ngay_tao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nguoi_tao` int(11) DEFAULT NULL,
  `ngay_cap_nhat` timestamp NULL DEFAULT NULL,
  `nguoi_cap_nhat` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-ts_ct_bao_gia_sua_chua-id_bao_gia` (`id_bao_gia`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_ct_bao_gia_sua_chua`
--

INSERT INTO `ts_ct_bao_gia_sua_chua` (`id`, `id_bao_gia`, `id_dm_bao_gia`, `ten_danh_muc`, `so_luong`, `don_vi_tinh`, `don_gia`, `thanh_tien`, `ngay_tao`, `nguoi_tao`, `ngay_cap_nhat`, `nguoi_cap_nhat`) VALUES
(1, 1, 2, 'fdfasd', 10, 'fdsafasd', '1000000.00', '10000000.00', '2024-05-27 05:21:22', 1, '2024-05-27 05:21:22', NULL),
(2, 2, 1, 'fdasfa', 10, 'Cái', '500000.00', '5000000.00', '2024-05-27 05:28:59', 1, '2024-05-27 05:28:59', NULL),
(3, 4, 2, 'fsadfasf', 1, 'Cái', '1000000.00', '1000000.00', '2024-05-30 14:09:53', 1, '2024-05-30 14:09:53', NULL),
(4, 6, 1, 'fasfda', 10, 'fasf', '1000000.00', '10000000.00', '2024-05-30 14:34:55', 1, '2024-05-30 14:34:55', NULL),
(5, 7, 2, 'fsafaf', 2, 'fasfdaf', '1000000.00', '2000000.00', '2024-05-30 14:36:19', 1, '2024-05-30 14:36:19', NULL),
(6, 9, 2, 'fdfsda', 10, 'Cái', '1000000.00', '10000000.00', '2024-05-31 01:17:51', 1, '2024-05-31 01:17:51', NULL),
(7, 13, 1, 'fdfasd', 10, 'fdsafasd', '1000000.00', '10000000.00', '2024-06-05 03:21:23', 1, '2024-06-05 03:21:23', NULL),
(8, 13, 1, 'dhfh', 10, 'fdsafasd', '1000000.00', '10000000.00', '2024-06-05 03:21:32', 1, '2024-06-05 03:21:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ts_dm_tt_sua_chua`
--

DROP TABLE IF EXISTS `ts_dm_tt_sua_chua`;
CREATE TABLE IF NOT EXISTS `ts_dm_tt_sua_chua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_tt_sua_chua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dien_thoai1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dien_thoai2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `nguoi_lien_he` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `danh_gia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_dm_tt_sua_chua`
--

INSERT INTO `ts_dm_tt_sua_chua` (`id`, `ten_tt_sua_chua`, `dien_thoai1`, `dien_thoai2`, `dia_chi`, `nguoi_lien_he`, `danh_gia`) VALUES
(1, 'Trung tâm sửa chữa 1', '0123', '4567', 'địa chỉ', 'Nguyễn Văn A', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ts_dm_vat_tu`
--

DROP TABLE IF EXISTS `ts_dm_vat_tu`;
CREATE TABLE IF NOT EXISTS `ts_dm_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_vat_tu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `id_kho` int(11) DEFAULT NULL,
  `don_vi_tinh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hang_san_xuat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trang_thai` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` decimal(10,2) DEFAULT NULL,
  `ngay_tao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-ts_dm_vat_tu-id_kho` (`id_kho`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_dm_vat_tu`
--

INSERT INTO `ts_dm_vat_tu` (`id`, `ten_vat_tu`, `so_luong`, `id_kho`, `don_vi_tinh`, `hang_san_xuat`, `trang_thai`, `don_gia`, `ngay_tao`, `nguoi_tao`) VALUES
(1, 'xxx', 83, 1, 'Cái', 'ABC', 'new', '50000.00', '2024-05-27 05:25:29', 1),
(2, 'yyy', 15, 2, 'Cái', 'abc', 'new', '100000.00', '2024-05-27 05:26:54', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_doi_tac`
--

DROP TABLE IF EXISTS `ts_doi_tac`;
CREATE TABLE IF NOT EXISTS `ts_doi_tac` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_doi_tac` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_doi_tac` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_nhom_doi_tac` int(11) NOT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `dien_thoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tai_khoan_ngan_hang` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ma_so_thue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `la_nha_cung_cap` tinyint(1) DEFAULT NULL,
  `la_khach_hang` tinyint(1) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_doi_tac` (`id_nhom_doi_tac`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_doi_tac`
--

INSERT INTO `ts_doi_tac` (`id`, `ma_doi_tac`, `ten_doi_tac`, `id_nhom_doi_tac`, `dia_chi`, `dien_thoai`, `email`, `tai_khoan_ngan_hang`, `ma_so_thue`, `la_nha_cung_cap`, `la_khach_hang`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(13, 'DT01', 'Công ty A', 1, 'TP HCM', '01234', 'ctya@gmail.com', '123', '1234', 1, 0, '2023-08-15 14:21:54', 1),
(14, 'DT02', 'Công ty B', 2, 'Trà Vinh', '7890', NULL, '456', '55555', 0, 1, '2023-08-15 14:21:54', 1),
(15, 'DT03', 'Công ty C', 2, ' ', NULL, NULL, NULL, NULL, 1, 0, '2023-08-15 14:21:54', 1),
(16, 'DT04', 'Công ty D', 1, NULL, NULL, NULL, NULL, NULL, 1, 0, '2023-08-15 14:21:54', 1),
(17, 'DT05', 'Công ty E', 2, NULL, NULL, NULL, NULL, NULL, 1, 0, '2023-08-15 14:21:54', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_he_thong`
--

DROP TABLE IF EXISTS `ts_he_thong`;
CREATE TABLE IF NOT EXISTS `ts_he_thong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_he_thong` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_he_thong` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `truc_thuoc` int(11) DEFAULT NULL,
  `mo_ta` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_he_thong`
--

INSERT INTO `ts_he_thong` (`id`, `ma_he_thong`, `ten_he_thong`, `truc_thuoc`, `mo_ta`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'HT001', 'Hệ thống máy trộn bê tông', NULL, '', NULL, NULL),
(2, 'VT01', 'Hệ thống trộn Bê Tông Khu Công nghiệp', 0, 'ghi chú 1', '2023-08-02 07:46:57', 1),
(3, 'VT02', 'Hệ thống dập TOL', 0, NULL, '2023-08-02 07:46:57', 1),
(4, 'VT03', 'Hệ thống trộn Bê Tông Duyên Hải', 0, NULL, '2023-08-02 07:46:57', 1),
(5, 'VT04', 'Hệ thống thí nghiệm 1', 0, NULL, '2023-08-02 07:46:57', 1),
(6, 'BT-KCN', 'Hệ thống thí nghiệm 2', 5, '', '2023-08-02 07:46:57', 1),
(7, 'ABC', 'Hệ thống TN 2', 5, 'ccc', '2023-08-18 16:23:05', 1),
(8, 'HT00333', 'fasdfaf', 7, '', '2023-08-21 10:43:59', 1),
(9, 'HT001666', 'fdsafasfffff22', 7, '', '2023-08-21 10:44:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_hinh_anh`
--

DROP TABLE IF EXISTS `ts_hinh_anh`;
CREATE TABLE IF NOT EXISTS `ts_hinh_anh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `ten_hien_thi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duong_dan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_file_luu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_hinh_anh`
--

INSERT INTO `ts_hinh_anh` (`id`, `loai`, `id_tham_chieu`, `ten_hien_thi`, `duong_dan`, `ten_file_luu`, `img_extension`, `img_size`, `img_wh`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(60, 'nhanvien', 4, '', 'ed3157a0407910d797205eb21ff9a536.png', 'fubusta_lines_qr_code_192720766.png', 'png', 318, NULL, '', '2023-07-27 09:46:55', 1),
(65, 'nhanvien', 4, '', '6c2b00941d0b18faa721d2c510164c68.jpg', 'tuyendung.jpg', 'jpg', 83283, NULL, '', '2023-08-08 14:46:49', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_history`
--

DROP TABLE IF EXISTS `ts_history`;
CREATE TABLE IF NOT EXISTS `ts_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `noi_dung` text COLLATE utf8_unicode_ci NOT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_history`
--

INSERT INTO `ts_history` (`id`, `loai`, `id_tham_chieu`, `noi_dung`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'nhanvien', 4, '<p>Thay đổi Tên truy cập \"\" thành \"superadmin\"</p>', '2023-08-09 14:04:38', 1),
(2, 'nhanvien', 4, '<p>Thay đổi Tên truy cập \"superadmin\" thành \"u001\"</p>', '2023-08-09 14:05:06', 1),
(3, 'thietbi', 35, '<p>Thay đổi Bộ phận quản lý \"1\" thành \"2\"</p><p>Thay đổi Người quản lý \"4\" thành \"39\"</p>', '2023-08-09 14:07:59', 1),
(4, 'nhanvien', 4, '<p>Thay đổi Tên truy cập \"u001\" thành \"superadmin\"</p>', '2023-08-09 14:30:54', 1),
(5, 'nhanvien', 4, '<p>Thay đổi Thuộc bộ phận \"3\" thành \"1\"</p>', '2023-08-09 14:36:21', 1),
(6, 'nhanvien', 4, '<p>Thay đổi Thuộc bộ phận \"1\" thành \"2\"</p>', '2023-08-09 14:36:43', 1),
(7, 'taikhoan', 16, '<p>Thay đổi Password Hash \"$2y$13$rPQnpSbV67F8gqaX47jCcut3JxqobYKmVImX2HRIDqNVjMmf0OtQS\" thành \"$2y$13$JgC6cAT4LRKdfsyu0L1IpO27sqtobc9Jclhn.CDrIsmDt/ejilmhq\"</p><p>Thay đổi Updated \"1691400376\" thành \"1691628856\"</p>', '2023-08-10 07:54:16', 1),
(8, 'nhanvien', 4, '<p>Thay đổi Tên truy cập \"superadmin\" thành \"tyan4\"</p>', '2023-08-10 14:22:15', 1),
(9, 'taikhoan', 17, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-10 14:38:20', 1),
(10, 'taikhoan', 18, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-10 14:41:42', 1),
(11, 'taikhoan', 6, '<p>Thay đổi Updated \"1691375956\" thành \"1691653348\"</p>', '2023-08-10 14:42:28', 18),
(12, 'taikhoan', 19, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-10 14:49:11', 1),
(13, 'taikhoan', 20, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-10 14:50:06', 1),
(19, 'bophan', 17, '<p>Thay đổi Trực thuộc \"0\" thành \"\"</p>', '2023-08-15 14:13:41', 1),
(20, 'doitac', 13, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-15 14:21:54', 1),
(21, 'doitac', 14, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-15 14:21:54', 1),
(22, 'doitac', 15, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-15 14:21:54', 1),
(23, 'doitac', 16, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-15 14:21:54', 1),
(24, 'doitac', 17, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-15 14:21:54', 1),
(27, 'taikhoan', 2, '<p>Thay đổi Updated \"1691054879\" thành \"1692154781\"</p>', '2023-08-16 09:59:41', 1),
(28, 'nhanvien', 4, '<p>Thay đổi Tên truy cập \"tyan4\" thành \"tyan6\"</p>', '2023-08-17 14:53:43', 1),
(29, 'taikhoan', 20, '<p>Thay đổi Password Hash \"$2y$13$0/iJJ1IYNZYxHyUFEgwiYOVRRgEQEmJoUNtIrISfW5U8INcgtrqg.\" thành \"$2y$13$pMiVv.kPAMVWhVDiHh7VD./8.6Cdj62I8EkPcdnavC.5UNCSgI2EK\"</p><p>Thay đổi Updated \"1691653806\" thành \"1692258835\"</p>', '2023-08-17 14:53:55', 1),
(31, 'hethong', 7, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-18 16:23:05', 1),
(32, 'hethong', 8, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-21 10:43:59', 1),
(33, 'hethong', 9, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-21 10:44:08', 1),
(34, 'nhanvien', 45, 'Thực hiện thêm mới dữ liệu thành công.', '2023-08-21 16:45:08', 1),
(36, 'bophan', 18, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:38:28', 1),
(37, 'thiet-bi', 43, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:39:24', 1),
(38, 'thiet-bi', 44, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:39:26', 1),
(39, 'thiet-bi', 45, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:39:28', 1),
(40, 'thiet-bi', 46, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:39:30', 1),
(41, 'thiet-bi', 47, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:39:32', 1),
(42, 'thiet-bi', 48, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:39:34', 1),
(43, 'thiet-bi', 49, 'Thực hiện thêm mới dữ liệu thành công.', '2024-04-24 12:39:36', 1),
(44, 'thiet-bi', 45, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-05-30 21:06:34', 1),
(45, 'thiet-bi', 45, '<p>Thay đổi Trạng thái \"SUACHUA\" thành \"HOATDONG\"</p>', '2024-05-30 21:09:15', 1),
(46, 'taikhoan', 2, '<p>Thay đổi Password Hash \"$2y$13$c2TRCwOzJvGHD4DUeucfSuMMkJzIG0JIVybnE/chlgp.fSsu1zg96\" thành \"$2y$13$Q6ZeEK7f/YE2NC8bfWxXZO.pYk/KbPhPWFhjVasFkVchBEdvmo2.y\"</p><p>Thay đổi Updated \"1692154781\" thành \"1717078493\"</p>', '2024-05-30 21:14:53', 1),
(47, 'taikhoan', 2, '<p>Thay đổi Updated \"1717078493\" thành \"1717078524\"</p><p>Thay đổi Liên kết với địa chỉ IP \"192.168.1.1\" thành \"\"</p>', '2024-05-30 21:15:24', 1),
(48, 'thiet-bi', 47, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-05-30 21:31:49', 1),
(49, 'thiet-bi', 47, '<p>Thay đổi Trạng thái \"SUACHUA\" thành \"HOATDONG\"</p>', '2024-05-30 21:32:15', 1),
(50, 'thiet-bi', 48, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-05-30 21:34:29', 1),
(51, 'thiet-bi', 48, '<p>Thay đổi Trạng thái \"SUACHUA\" thành \"HOATDONG\"</p>', '2024-05-30 21:38:24', 1),
(52, 'thiet-bi', 48, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-05-30 21:39:41', 1),
(53, 'thiet-bi', 48, '<p>Thay đổi Trạng thái \"SUACHUA\" thành \"HOATDONG\"</p>', '2024-05-31 08:06:34', 1),
(54, 'thiet-bi', 47, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-05-31 08:17:33', 1),
(55, 'thiet-bi', 44, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-06-05 09:41:51', 1),
(56, 'baotri', 1, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-05 09:44:48', 1),
(57, 'thiet-bi', 44, '<p>Thay đổi Trạng thái \"SUACHUA\" thành \"HOATDONG\"</p>', '2024-06-05 10:18:52', 1),
(58, 'thiet-bi', 43, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-06-05 10:20:07', 1),
(59, 'thiet-bi', 43, '<p>Thay đổi Trạng thái \"SUACHUA\" thành \"HOATDONG\"</p>', '2024-06-05 10:20:13', 1),
(60, 'thiet-bi', 43, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-06-05 10:20:52', 1),
(61, 'thiet-bi', 45, '<p>Thay đổi Trạng thái \"HOATDONG\" thành \"SUACHUA\"</p>', '2024-06-05 10:22:27', 1),
(62, 'baotri', 1, '<p>Thay đổi Tần suất \"\" thành \"1\"</p>', '2024-06-24 08:39:49', 1),
(63, 'baotri', 1, '<p>Thay đổi Tần suất \"1\" thành \"0\"</p>', '2024-06-25 14:08:23', 1),
(64, 'baotri', 1, '<p>Thay đổi Tần suất \"0\" thành \"1\"</p>', '2024-06-25 14:09:46', 1),
(65, 'phieubaotri', 1, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 10:28:31', 1),
(66, 'phieubaotri', 2, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 10:28:31', 1),
(67, 'phieubaotri', 3, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 10:28:31', 1),
(68, 'phieubaotri', 4, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 10:28:31', 1),
(69, 'phieubaotri', 5, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 10:28:31', 1),
(70, 'phieubaotri', 1, '<p>Thay đổi Đơn vị bảo trì \"1\" thành \"3\"</p>', '2024-06-26 22:32:11', 1),
(71, 'phieubaotri', 1, '<p>Thay đổi Đã hoàn thành \"\" thành \"1\"</p>', '2024-06-26 22:40:39', 1),
(72, 'phieubaotri', 6, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:10:55', 1),
(73, 'phieubaotri', 7, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:10:55', 1),
(74, 'phieubaotri', 8, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:10:55', 1),
(75, 'phieubaotri', 9, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:10:55', 1),
(76, 'phieubaotri', 10, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:10:55', 1),
(77, 'baotri', 2, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:37:57', 1),
(78, 'phieubaotri', 11, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:38:04', 1),
(79, 'phieubaotri', 12, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:38:04', 1),
(80, 'phieubaotri', 13, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:38:04', 1),
(81, 'phieubaotri', 14, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:38:04', 1),
(82, 'phieubaotri', 15, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:38:04', 1),
(83, 'baotri', 3, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:48:55', 1),
(84, 'baotri', 3, '<p>Thay đổi Thiết bị \"44\" thành \"43\"</p>', '2024-06-26 23:50:12', 1),
(85, 'baotri', 3, '<p>Thay đổi Ngày bắt đầu \"1970-01-01\" thành \"2024-06-27\"</p>', '2024-06-26 23:51:21', 1),
(86, 'baotri', 4, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:52:00', 1),
(87, 'phieubaotri', 16, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:52:06', 1),
(88, 'phieubaotri', 17, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-26 23:52:06', 1),
(89, 'phieubaotri', 11, '<p>Thay đổi Thời gian kết thúc \"\" thành \"2024-06-06 00:00:00\"</p>', '2024-06-27 00:09:34', 1),
(90, 'phieubaotri', 11, '<p>Thay đổi Đã hoàn thành \"0\" thành \"1\"</p>', '2024-06-27 00:09:40', 1),
(91, 'baotri', 5, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:01:43', 1),
(92, 'baotri', 5, '<p>Thay đổi Ngày bắt đầu \"1970-01-01\" thành \"2024-06-27\"</p>', '2024-06-27 11:02:00', 1),
(93, 'phieubaotri', 18, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:13', 1),
(94, 'phieubaotri', 19, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:13', 1),
(95, 'phieubaotri', 20, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:13', 1),
(96, 'phieubaotri', 21, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:13', 1),
(97, 'phieubaotri', 22, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:13', 1),
(98, 'phieubaotri', 23, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:14', 1),
(99, 'phieubaotri', 24, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:14', 1),
(100, 'phieubaotri', 25, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:14', 1),
(101, 'phieubaotri', 26, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:14', 1),
(102, 'phieubaotri', 27, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 11:02:14', 1),
(103, 'phieubaotri', 19, '<p>Thay đổi Thời gian bắt đầu \"2024-06-28 00:00:00\" thành \"2024-06-27 07:00:00\"</p>', '2024-06-27 14:12:16', 1),
(104, 'phieubaotri', 20, '<p>Thay đổi Thời gian bắt đầu \"2024-06-29 00:00:00\" thành \"2024-06-28 07:00:00\"</p>', '2024-06-27 14:13:30', 1),
(105, 'phieubaotri', 18, '<p>Thay đổi Thời gian bắt đầu \"2024-06-27 00:00:00\" thành \"2024-06-27 07:00:00\"</p><p>Thay đổi Đã hoàn thành \"0\" thành \"1\"</p>', '2024-06-27 14:23:56', 1),
(106, 'phieubaotri', 16, '<p>Thay đổi Thời gian bắt đầu \"2024-06-27 00:00:00\" thành \"2024-06-27 07:00:00\"</p><p>Thay đổi Đã hoàn thành \"0\" thành \"1\"</p>', '2024-06-27 14:25:08', 1),
(107, 'baotri', 6, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 14:59:28', 1),
(108, 'baotri', 6, '<p>Thay đổi Ngày bắt đầu \"1970-01-01\" thành \"2024-06-28\"</p>', '2024-06-27 15:06:42', 1),
(109, 'baotri', 7, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 15:07:37', 1),
(110, 'baotri', 8, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 15:11:49', 1),
(111, 'baotri', 9, 'Thực hiện thêm mới dữ liệu thành công.', '2024-06-27 15:14:50', 1),
(112, 'phieubaotri', 12, '<p>Thay đổi Thời gian bắt đầu \"2024-06-02 00:00:00\" thành \"2024-06-02 07:00:00\"</p><p>Thay đổi Nội dung thực hiện \"\" thành \"Đôi khi, các đồng dev có thể chỉ muốn áp dụng một hoặc một số migrate mới, thay vì tất cả các đồng dev có thể làm như vậy bằng cách chỉ định số lần migrate muốn áp dụng khi chạy lệnh. Ví dụ: lệnh sau sẽ cố gắng áp dụng 2 lần migrate đã có \"</p>', '2024-06-27 22:04:31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_ke_hoach_bao_tri`
--

DROP TABLE IF EXISTS `ts_ke_hoach_bao_tri`;
CREATE TABLE IF NOT EXISTS `ts_ke_hoach_bao_tri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_he_thong` int(11) DEFAULT NULL,
  `id_thiet_bi` int(11) NOT NULL,
  `id_chi_tiet` int(11) DEFAULT NULL,
  `ten_cong_viec` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_loai_bao_tri` int(11) NOT NULL,
  `ngay_bat_dau` date DEFAULT NULL,
  `bao_truoc` smallint(6) NOT NULL,
  `can_cu` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `so_ky` tinyint(4) DEFAULT NULL,
  `ky_bao_tri` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tan_suat` int(11) DEFAULT NULL,
  `id_don_vi_bao_tri` int(11) NOT NULL,
  `id_nguoi_chiu_trach_nhiem` int(11) NOT NULL,
  `muc_do_uu_tien` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `truc_thuoc` int(11) DEFAULT NULL,
  `thoi_gian_thuc_hien` float DEFAULT NULL,
  `don_vi_thoi_gian` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dung_may` tinyint(1) DEFAULT NULL,
  `thue_ngoai` tinyint(1) DEFAULT NULL,
  `da_het_hieu_luc` tinyint(1) DEFAULT NULL,
  `ngay_het_hieu_luc` date DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `ngay_thuc_hien` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_thiet_bi` (`id_thiet_bi`),
  KEY `id_loai_bao_tri` (`id_loai_bao_tri`),
  KEY `id_don_vi_bao_tri` (`id_don_vi_bao_tri`),
  KEY `id_nguoi_chiu_trach_nhiem` (`id_nguoi_chiu_trach_nhiem`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_ke_hoach_bao_tri`
--

INSERT INTO `ts_ke_hoach_bao_tri` (`id`, `id_he_thong`, `id_thiet_bi`, `id_chi_tiet`, `ten_cong_viec`, `id_loai_bao_tri`, `ngay_bat_dau`, `bao_truoc`, `can_cu`, `so_ky`, `ky_bao_tri`, `tan_suat`, `id_don_vi_bao_tri`, `id_nguoi_chiu_trach_nhiem`, `muc_do_uu_tien`, `truc_thuoc`, `thoi_gian_thuc_hien`, `don_vi_thoi_gian`, `dung_may`, `thue_ngoai`, `da_het_hieu_luc`, `ngay_het_hieu_luc`, `thoi_gian_tao`, `nguoi_tao`, `ngay_thuc_hien`) VALUES
(2, NULL, 43, NULL, 'Vệ sinh máy', 1, '2024-06-01', 10, '', 5, '1', 1, 1, 4, '0', NULL, 30, 'phút', 0, 0, 0, NULL, '2024-06-26 23:37:57', 1, NULL),
(4, NULL, 43, NULL, 'Vệ sinh máy', 1, '2024-06-27', 10, '', 2, '2', 2, 2, 38, '0', NULL, NULL, '', 0, 0, 0, NULL, '2024-06-26 23:52:00', 1, NULL),
(5, NULL, 43, NULL, 'Thay RAM', 1, '2024-06-27', 10, '', 10, '1', 1, 3, 38, '0', NULL, 1, 'Giờ', 0, 0, 0, NULL, '2024-06-27 11:01:43', 1, NULL),
(6, NULL, 44, NULL, 'Bảo trì dầu nhớt máy', 2, '2024-06-28', 10, '', 5, '1', 10, 1, 4, '0', NULL, 2, 'Giờ', 0, 0, 0, NULL, '2024-06-27 14:59:28', 1, NULL),
(7, NULL, 44, NULL, 'Vệ sinh máy', 1, '2024-06-28', 10, '', 5, '1', 1, 2, 38, '0', NULL, NULL, 'Giờ', 0, 0, 0, NULL, '2024-06-27 15:07:37', 1, NULL),
(8, NULL, 43, NULL, 'Vệ sinh máy', 1, '2024-06-28', 10, '', 5, '1', 1, 2, 38, '0', NULL, 2, 'Giờ', 0, 0, 0, NULL, '2024-06-27 15:11:49', 1, NULL),
(9, NULL, 43, NULL, 'Thay RAM', 1, '2024-06-28', 10, '', 5, '1', 1, 2, 4, '0', NULL, 2, 'Giờ', 0, 0, 0, NULL, '2024-06-27 15:14:50', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ts_kho_luu_tru`
--

DROP TABLE IF EXISTS `ts_kho_luu_tru`;
CREATE TABLE IF NOT EXISTS `ts_kho_luu_tru` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_kho` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_kho` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `loai_kho` int(11) NOT NULL,
  `id_nguoi_quan_ly` int(11) NOT NULL,
  `id_bo_phan_quan_ly` int(11) NOT NULL,
  `gia_tri_toi_da` int(11) DEFAULT NULL,
  `dien_thoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nguoi_quan_ly` (`id_nguoi_quan_ly`),
  KEY `id_bo_phan_quan_ly` (`id_bo_phan_quan_ly`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_kho_luu_tru`
--

INSERT INTO `ts_kho_luu_tru` (`id`, `ma_kho`, `ten_kho`, `loai_kho`, `id_nguoi_quan_ly`, `id_bo_phan_quan_ly`, `gia_tri_toi_da`, `dien_thoai`, `email`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'KH001', 'Kho vật tư', 1, 4, 1, 500, '0123', 'nguyenvantyan@gmail.com', '2023-07-22 10:29:18', 1),
(2, 'KH002', 'Kho phế liệu Văn phòng', 1, 4, 1, NULL, '', '', '2023-07-22 10:29:39', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_lich_su_vat_tu`
--

DROP TABLE IF EXISTS `ts_lich_su_vat_tu`;
CREATE TABLE IF NOT EXISTS `ts_lich_su_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_vat_tu` int(11) NOT NULL,
  `so_luong_cu` int(11) NOT NULL,
  `so_luong_moi` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `nguoi_tao` int(11) NOT NULL,
  `ngay_tao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk-ts_lich_su_vat_tu-id_vat_tu` (`id_vat_tu`),
  KEY `fk-ts_lich_su_vat_tu-nguoi_tao` (`nguoi_tao`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_lich_su_vat_tu`
--

INSERT INTO `ts_lich_su_vat_tu` (`id`, `id_vat_tu`, `so_luong_cu`, `so_luong_moi`, `so_luong`, `ghi_chu`, `nguoi_tao`, `ngay_tao`) VALUES
(1, 1, 100, 99, -1, 'Sửa chữa thiết bị Máy tính bàn ', 1, '2024-05-30 14:04:03'),
(2, 1, 99, 98, -1, 'Sửa chữa thiết bị Máy tính bàn ', 1, '2024-05-30 14:04:16'),
(3, 1, 98, 93, -5, 'Sửa chữa thiết bị Máy D5', 1, '2024-05-30 14:24:21'),
(4, 2, 20, 15, -5, 'Sửa chữa thiết bị Máy photocopy TOSHIBA', 1, '2024-05-30 14:38:17'),
(5, 1, 93, 83, -10, 'Sửa chữa thiết bị Máy trộn bê tông', 1, '2024-06-05 03:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `ts_loai_bao_tri`
--

DROP TABLE IF EXISTS `ts_loai_bao_tri`;
CREATE TABLE IF NOT EXISTS `ts_loai_bao_tri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_loai_bao_tri`
--

INSERT INTO `ts_loai_bao_tri` (`id`, `ten`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'Loại bảo trì 1', 'loại bảo trì 1 ghi chú', '2023-08-02 07:49:58', 1),
(2, 'Loại bảo trì 2', 'ghi chú 2', '2023-08-02 07:50:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_loai_thiet_bi`
--

DROP TABLE IF EXISTS `ts_loai_thiet_bi`;
CREATE TABLE IF NOT EXISTS `ts_loai_thiet_bi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_loai` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `don_vi_tinh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `truc_thuoc` int(11) DEFAULT NULL,
  `loai_thiet_bi` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_loai_thiet_bi`
--

INSERT INTO `ts_loai_thiet_bi` (`id`, `ma_loai`, `ten_loai`, `don_vi_tinh`, `truc_thuoc`, `loai_thiet_bi`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'LOAI01', 'Máy vi tính', 'Cái', NULL, 'COGIOI', '', '2023-07-27 14:34:28', 1),
(3, 'LOAI03', 'Chuột máy tính', 'Cái', 1, 'VANCHUYEN', '', '2023-08-01 08:55:59', 1),
(4, 'LOAI01xx', 'xcxcxc', '', 0, 'THIETBI', '', '2023-08-01 09:37:12', 1),
(5, 'LTB001', 'Xe tải', NULL, 0, 'COGIOI', 'ghi chú 1', '2023-08-02 07:48:17', 1),
(6, 'LTB002', 'Xe container', NULL, 0, 'COGIOI', NULL, '2023-08-02 07:48:17', 1),
(7, 'LTB003', 'Xe lu', NULL, 0, 'COGIOI', NULL, '2023-08-02 07:48:18', 1),
(8, 'LTB004', 'Máy tính', NULL, 5, 'COGIOI', NULL, '2023-08-02 07:48:18', 1),
(9, 'MVT', 'Máy in', '', 6, 'COGIOI', 'ghi chú 5', '2023-08-02 07:48:18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_lop_hu_hong`
--

DROP TABLE IF EXISTS `ts_lop_hu_hong`;
CREATE TABLE IF NOT EXISTS `ts_lop_hu_hong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_lop` varchar(50) NOT NULL,
  `ten_lop` varchar(200) NOT NULL,
  `ngay_tao` date NOT NULL,
  `nguoi_tao` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ts_lop_hu_hong`
--

INSERT INTO `ts_lop_hu_hong` (`id`, `ma_lop`, `ten_lop`, `ngay_tao`, `nguoi_tao`) VALUES
(1, 'yyyy', '	Hư hỏng máy nén khí 01', '2023-07-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_nhan_vien`
--

DROP TABLE IF EXISTS `ts_nhan_vien`;
CREATE TABLE IF NOT EXISTS `ts_nhan_vien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_bo_phan` int(11) NOT NULL,
  `ma_nhan_vien` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_nhan_vien` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ngay_sinh` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gioi_tinh` tinyint(1) DEFAULT NULL,
  `chuc_vu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_truy_cap` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_vao_lam` date DEFAULT NULL,
  `da_thoi_viec` tinyint(1) DEFAULT NULL,
  `ngay_thoi_viec` date DEFAULT NULL,
  `dien_thoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_bo_phan` (`id_bo_phan`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_nhan_vien`
--

INSERT INTO `ts_nhan_vien` (`id`, `id_bo_phan`, `ma_nhan_vien`, `ten_nhan_vien`, `ngay_sinh`, `gioi_tinh`, `chuc_vu`, `ten_truy_cap`, `ngay_vao_lam`, `da_thoi_viec`, `ngay_thoi_viec`, `dien_thoai`, `email`, `dia_chi`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(4, 2, 'NV0090', 'Nguyễn Văn C1', '01/01/1988', 1, 'Nhân viên', 'tyan6', NULL, 0, NULL, '', '', '', '2023-07-27 08:23:56', 1),
(38, 2, 'NV001', 'Chung Tử Đơn', '01/01/1989', 0, 'Nhân viên', NULL, '1970-01-01', NULL, NULL, '123456789', 'chtdon@gmail.com', 'Càng Long', '2023-08-08 14:48:03', 1),
(39, 2, 'NV002', 'Lý Liên Kiệt', '02/02/1991', 0, 'Trưởng phòng', NULL, NULL, NULL, NULL, '0374711908', NULL, NULL, '2023-08-08 14:48:03', 1),
(40, 2, 'NV003', 'Thái Thiếu Phân', '1980', 1, 'Phó phòng', NULL, NULL, NULL, NULL, '090009900', NULL, NULL, '2023-08-08 14:48:03', 1),
(41, 2, 'NV004', 'Đường Tư', '1989', 1, 'Nhân viên', NULL, NULL, NULL, NULL, NULL, NULL, 'Trà Vinh', '2023-08-08 14:48:03', 1),
(42, 2, 'NV005', 'Nhâm Mạnh Đạt', '22/12/2000', 0, 'Nhân viên', NULL, '1970-01-01', NULL, NULL, NULL, NULL, NULL, '2023-08-08 14:48:03', 1),
(43, 2, 'NV006', 'Châu Tinh Trì', '20/11/1992', 0, 'Nhân viên', NULL, NULL, NULL, NULL, NULL, 'cttri@gmail.com', NULL, '2023-08-08 14:48:03', 1),
(44, 2, 'NV007', 'Trần Long Ẩn', '15/07/1999', 0, 'Nhân viên', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-08-08 14:48:03', 1),
(45, 1, 'aaaa', 'fsadfasfa', '', 0, '', '', NULL, 0, NULL, '', '', '', '2023-08-21 16:45:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_nhan_vien_kho`
--

DROP TABLE IF EXISTS `ts_nhan_vien_kho`;
CREATE TABLE IF NOT EXISTS `ts_nhan_vien_kho` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_bat_dau` date DEFAULT NULL,
  `ngay_ket_thuc` date DEFAULT NULL,
  `la_quan_ly_kho` tinyint(1) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho` (`id_kho`),
  KEY `id_nhan_vien` (`id_nhan_vien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ts_nhom_doi_tac`
--

DROP TABLE IF EXISTS `ts_nhom_doi_tac`;
CREATE TABLE IF NOT EXISTS `ts_nhom_doi_tac` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_nhom` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_nhom_doi_tac`
--

INSERT INTO `ts_nhom_doi_tac` (`id`, `ma_nhom`, `ten_nhom`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'NDT01', 'Nhóm đối tác 1', '2023-07-31 14:20:15', 1),
(2, 'NDT02', 'Nhóm đối tác 2', '2023-07-31 14:20:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_phieu_bao_tri`
--

DROP TABLE IF EXISTS `ts_phieu_bao_tri`;
CREATE TABLE IF NOT EXISTS `ts_phieu_bao_tri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ke_hoach` int(11) DEFAULT NULL,
  `ky_thu` int(11) DEFAULT NULL,
  `id_don_vi_bao_tri` int(11) DEFAULT NULL,
  `id_nguoi_chiu_trach_nhiem` int(11) DEFAULT NULL,
  `thoi_gian_bat_dau` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `thoi_gian_ket_thuc` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `noi_dung_thuc_hien` text COLLATE utf8_unicode_ci,
  `da_hoan_thanh` tinyint(1) DEFAULT NULL,
  `thoi_gian_tao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-ts_phieu_bao_tri-id_ke_hoach` (`id_ke_hoach`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_phieu_bao_tri`
--

INSERT INTO `ts_phieu_bao_tri` (`id`, `id_ke_hoach`, `ky_thu`, `id_don_vi_bao_tri`, `id_nguoi_chiu_trach_nhiem`, `thoi_gian_bat_dau`, `thoi_gian_ket_thuc`, `noi_dung_thuc_hien`, `da_hoan_thanh`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(11, 2, 1, 1, 4, '2024-05-31 17:00:00', '2024-06-05 17:00:00', '', 1, '2024-06-26 16:38:04', 1),
(12, 2, 2, 1, 4, '2024-06-02 00:00:00', NULL, 'Đôi khi, các đồng dev có thể chỉ muốn áp dụng một hoặc một số migrate mới, thay vì tất cả các đồng dev có thể làm như vậy bằng cách chỉ định số lần migrate muốn áp dụng khi chạy lệnh. Ví dụ: lệnh sau sẽ cố gắng áp dụng 2 lần migrate đã có ', 0, '2024-06-26 16:38:04', 1),
(13, 2, 3, 1, 4, '2024-06-02 17:00:00', NULL, '', 0, '2024-06-26 16:38:04', 1),
(14, 2, 4, 1, 4, '2024-06-03 17:00:00', NULL, '', 0, '2024-06-26 16:38:04', 1),
(15, 2, 5, 1, 4, '2024-06-04 17:00:00', NULL, '', 0, '2024-06-26 16:38:04', 1),
(16, 4, 1, 2, 38, '2024-06-27 00:00:00', NULL, '', 1, '2024-06-26 16:52:06', 1),
(17, 4, 2, 2, 38, '2024-07-10 17:00:00', NULL, '', 0, '2024-06-26 16:52:06', 1),
(18, 5, 1, 3, 38, '2024-06-27 00:00:00', NULL, '', 1, '2024-06-27 04:02:13', 1),
(19, 5, 2, 3, 38, '2024-06-27 00:00:00', NULL, '', 0, '2024-06-27 04:02:13', 1),
(20, 5, 3, 3, 38, '2024-06-28 00:00:00', NULL, '', 0, '2024-06-27 04:02:13', 1),
(21, 5, 4, 3, 38, '2024-06-29 17:00:00', NULL, '', 0, '2024-06-27 04:02:13', 1),
(22, 5, 5, 3, 38, '2024-06-30 17:00:00', NULL, '', 0, '2024-06-27 04:02:13', 1),
(23, 5, 6, 3, 38, '2024-07-01 17:00:00', NULL, '', 0, '2024-06-27 04:02:13', 1),
(24, 5, 7, 3, 38, '2024-07-02 17:00:00', NULL, '', 0, '2024-06-27 04:02:14', 1),
(25, 5, 8, 3, 38, '2024-07-03 17:00:00', NULL, '', 0, '2024-06-27 04:02:14', 1),
(26, 5, 9, 3, 38, '2024-07-04 17:00:00', NULL, '', 0, '2024-06-27 04:02:14', 1),
(27, 5, 10, 3, 38, '2024-07-05 17:00:00', NULL, '', 0, '2024-06-27 04:02:14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_phieu_sua_chua`
--

DROP TABLE IF EXISTS `ts_phieu_sua_chua`;
CREATE TABLE IF NOT EXISTS `ts_phieu_sua_chua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_thiet_bi` int(11) NOT NULL,
  `id_tt_sua_chua` int(11) NOT NULL,
  `ngay_sua_chua` datetime DEFAULT NULL,
  `ngay_du_kien_hoan_thanh` datetime DEFAULT NULL,
  `ngay_hoan_thanh` datetime DEFAULT NULL,
  `phi_linh_kien` decimal(10,2) DEFAULT NULL,
  `phi_khac` decimal(10,2) DEFAULT NULL,
  `tong_tien` decimal(10,2) DEFAULT NULL,
  `trang_thai` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_tao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nguoi_tao` int(11) DEFAULT NULL,
  `ngay_cap_nhat` timestamp NULL DEFAULT NULL,
  `nguoi_cap_nhat` int(11) DEFAULT NULL,
  `ghi_chu1` text COLLATE utf8_unicode_ci,
  `ghi_chu2` text COLLATE utf8_unicode_ci,
  `danh_gia_sc` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-ts_phieu_sua_chua-id_thiet_bi` (`id_thiet_bi`),
  KEY `fk-ts_phieu_sua_chua-id_tt_sua_chua` (`id_tt_sua_chua`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_phieu_sua_chua`
--

INSERT INTO `ts_phieu_sua_chua` (`id`, `id_thiet_bi`, `id_tt_sua_chua`, `ngay_sua_chua`, `ngay_du_kien_hoan_thanh`, `ngay_hoan_thanh`, `phi_linh_kien`, `phi_khac`, `tong_tien`, `trang_thai`, `dia_chi`, `ngay_tao`, `nguoi_tao`, `ngay_cap_nhat`, `nguoi_cap_nhat`, `ghi_chu1`, `ghi_chu2`, `danh_gia_sc`) VALUES
(1, 43, 1, '2024-05-04 00:00:00', '2024-05-31 00:00:00', NULL, NULL, '10000000.00', '10000000.00', 'completed', 'ccc', '2024-05-27 05:20:33', 1, NULL, NULL, 'mll;m;km', NULL, NULL),
(2, 44, 1, '2024-05-04 00:00:00', '2024-05-31 00:00:00', NULL, NULL, NULL, NULL, 'completed', 'fsadf', '2024-05-27 05:28:14', 1, NULL, NULL, 'fsadfa', NULL, NULL),
(3, 45, 1, '2024-05-02 00:00:00', '2024-05-05 00:00:00', '2024-05-05 00:00:00', NULL, '1000000.00', '1000000.00', 'completed', 'ccc', '2024-05-30 14:06:32', 1, NULL, NULL, 'bb', 'fasfa', NULL),
(4, 47, 1, '2024-05-01 00:00:00', '2024-05-03 00:00:00', '2024-05-03 00:00:00', NULL, NULL, NULL, 'completed', 'ccc', '2024-05-30 14:31:46', 1, NULL, NULL, 'dâfadsfa', NULL, NULL),
(5, 48, 1, '2024-05-01 00:00:00', '2024-05-02 00:00:00', '2024-05-02 00:00:00', '0.00', '0.00', '0.00', 'completed', 'gdsg', '2024-05-30 14:34:27', 1, NULL, NULL, 'gsdgs', NULL, NULL),
(6, 48, 1, '2024-05-04 00:00:00', '2024-05-24 00:00:00', '2024-05-24 00:00:00', NULL, NULL, NULL, 'completed', 'fasffasf', '2024-05-30 14:39:39', 1, NULL, NULL, 'fasf', NULL, NULL),
(7, 47, 1, '2024-05-01 00:00:00', '2024-05-04 00:00:00', '2024-05-04 00:00:00', NULL, '10000000.00', '10000000.00', 'processing', 'ccc', '2024-05-31 01:17:33', 1, NULL, NULL, 'll', NULL, NULL),
(8, 44, 1, '2024-06-01 00:00:00', '2024-06-10 00:00:00', '2024-06-10 00:00:00', NULL, NULL, NULL, 'new', 'fsadf', '2024-06-05 02:41:49', 1, NULL, NULL, 'đffg', NULL, NULL),
(9, 44, 1, '2024-06-01 00:00:00', '2024-06-10 00:00:00', '2024-06-10 00:00:00', '0.00', '0.00', '0.00', 'completed', 'dfg', '2024-06-05 02:52:52', 1, NULL, NULL, 'gdfg', NULL, NULL),
(10, 43, 1, '2024-06-01 00:00:00', '2024-06-11 00:00:00', '2024-06-11 00:00:00', NULL, NULL, NULL, 'completed', 'fasdf', '2024-06-05 03:20:07', 1, NULL, NULL, 'fadsf', NULL, NULL),
(11, 43, 1, '2024-06-01 00:00:00', '2024-06-10 00:00:00', '2024-06-10 00:00:00', '20000000.00', NULL, '20000000.00', 'processing', 'bvcb', '2024-06-05 03:20:51', 1, NULL, NULL, 'bb', NULL, NULL),
(12, 45, 1, '2024-06-01 00:00:00', '2024-06-10 00:00:00', '2024-06-10 00:00:00', NULL, NULL, NULL, 'new', 'fds', '2024-06-05 03:22:26', 1, NULL, NULL, 'ff', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ts_phieu_sua_chua_vat_tu`
--

DROP TABLE IF EXISTS `ts_phieu_sua_chua_vat_tu`;
CREATE TABLE IF NOT EXISTS `ts_phieu_sua_chua_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_phieu_sua_chua` int(11) NOT NULL,
  `id_vat_tu` int(11) NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `don_vi_tinh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_tao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nguoi_tao` int(11) DEFAULT NULL,
  `ngay_cap_nhat` timestamp NULL DEFAULT NULL,
  `nguoi_cap_nhat` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-ts_phieu_sua_chua_vat_tu-id_phieu_sua_chua` (`id_phieu_sua_chua`),
  KEY `fk-ts_phieu_sua_chua_vat_tu-id_vat_tu` (`id_vat_tu`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_phieu_sua_chua_vat_tu`
--

INSERT INTO `ts_phieu_sua_chua_vat_tu` (`id`, `id_phieu_sua_chua`, `id_vat_tu`, `so_luong`, `ghi_chu`, `don_vi_tinh`, `ngay_tao`, `nguoi_tao`, `ngay_cap_nhat`, `nguoi_cap_nhat`) VALUES
(1, 1, 1, 1, '', 'Cái', '2024-05-30 14:04:03', 1, '2024-05-30 14:04:03', 1),
(2, 1, 1, 1, '', 'Cái', '2024-05-30 14:04:16', 1, '2024-05-30 14:04:16', 1),
(3, 3, 1, 5, 'ff', 'Cái', '2024-05-30 14:24:21', 1, '2024-05-30 14:25:04', 1),
(4, 5, 2, 5, 'kk', 'Cái', '2024-05-30 14:38:17', 1, '2024-05-30 14:38:17', 1),
(5, 9, 1, 10, 'dsasd', 'Cái', '2024-06-05 02:54:04', 1, '2024-06-05 02:54:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_tai_lieu`
--

DROP TABLE IF EXISTS `ts_tai_lieu`;
CREATE TABLE IF NOT EXISTS `ts_tai_lieu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `ten_tai_lieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duong_dan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_file_luu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` float DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_tai_lieu`
--

INSERT INTO `ts_tai_lieu` (`id`, `loai`, `id_tham_chieu`, `ten_tai_lieu`, `duong_dan`, `ten_file_luu`, `file_extension`, `file_size`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(2, 'nhanvien', 4, 'xxxx', '4e00364886ba63c506cb9ea6888ffa8b.pdf', '[Nguyen Trinh] Quasoft Quotation (1).pdf', 'pdf', 586302, '', '2023-07-27 09:46:40', 1),
(3, 'nhanvien', 4, 'ddd', '49a2cf59b2fafed4a952d97561cb159d.xlsx', '_tinChi.xlsx', 'xlsx', 12009, '', '2023-07-27 13:46:06', 1),
(9, 'nhanvien', 4, 'test', '1e1848cc61ce6f23004dc03bcdfb7a33.xlsx', 'Book1.xlsx', 'xlsx', 71423, '', '2023-08-08 14:47:02', 1),
(10, 'baotri', 1, 'test', '2bfc4c89995dff2f2d00f21dfc6ceb0a.txt', 'adobe key.txt', 'txt', 49, 'b', '2024-06-24 08:51:31', 1),
(11, 'phieubaotri', 1, 'test', '640c64c12c2b208bd92be9cdc3b2c0b5.txt', 'adobe key.txt', 'txt', 49, 'fdasf', '2024-06-26 22:03:44', 1),
(12, 'phieubaotri', 1, 'test', '6a8175d2db8d4e11d895edac3d53c1e0.png', 'abode key.png', 'png', 48857, 'x', '2024-06-26 22:24:55', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_thiet_bi`
--

DROP TABLE IF EXISTS `ts_thiet_bi`;
CREATE TABLE IF NOT EXISTS `ts_thiet_bi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `autoid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ma_thiet_bi` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_vi_tri` int(11) DEFAULT NULL,
  `id_he_thong` int(11) DEFAULT NULL,
  `id_loai_thiet_bi` int(11) NOT NULL,
  `id_bo_phan_quan_ly` int(11) NOT NULL,
  `ten_thiet_bi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_thiet_bi_cha` int(11) DEFAULT NULL,
  `id_layout` int(11) DEFAULT NULL,
  `nam_san_xuat` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xuat_xu` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_hang_bao_hanh` int(11) DEFAULT NULL,
  `id_nhien_lieu` int(11) DEFAULT NULL,
  `dac_tinh_ky_thuat` text COLLATE utf8_unicode_ci,
  `id_lop_hu_hong` int(11) DEFAULT NULL,
  `id_trung_tam_chi_phi` int(11) DEFAULT NULL,
  `id_don_vi_bao_tri` int(11) DEFAULT NULL,
  `id_nguoi_quan_ly` int(11) NOT NULL,
  `ngay_mua` date DEFAULT NULL,
  `han_bao_hanh` date DEFAULT NULL,
  `ngay_dua_vao_su_dung` date DEFAULT NULL,
  `trang_thai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_ngung_hoat_dong` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_loai_thiet_bi` (`id_loai_thiet_bi`),
  KEY `id_bo_phan_quan_ly` (`id_bo_phan_quan_ly`),
  KEY `id_nguoi_quan_ly` (`id_nguoi_quan_ly`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_thiet_bi`
--

INSERT INTO `ts_thiet_bi` (`id`, `autoid`, `ma_thiet_bi`, `id_vi_tri`, `id_he_thong`, `id_loai_thiet_bi`, `id_bo_phan_quan_ly`, `ten_thiet_bi`, `id_thiet_bi_cha`, `id_layout`, `nam_san_xuat`, `serial`, `model`, `xuat_xu`, `id_hang_bao_hanh`, `id_nhien_lieu`, `dac_tinh_ky_thuat`, `id_lop_hu_hong`, `id_trung_tam_chi_phi`, `id_don_vi_bao_tri`, `id_nguoi_quan_ly`, `ngay_mua`, `han_bao_hanh`, `ngay_dua_vao_su_dung`, `trang_thai`, `ngay_ngung_hoat_dong`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(43, 'k11713937161', 'TB001', 2, 6, 9, 18, 'Máy tính bàn ', NULL, NULL, '', 'x', 'x', 'x', NULL, NULL, '', NULL, NULL, NULL, 38, NULL, NULL, NULL, 'SUACHUA', NULL, '', '2024-04-24 12:39:21', 1),
(44, 'h11713937164', 'TB002', 2, 6, 9, 18, 'Máy trộn bê tông', NULL, NULL, NULL, 'x', 'x', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 38, NULL, NULL, NULL, 'HOATDONG', NULL, NULL, '2024-04-24 12:39:24', 1),
(45, 'k11713937166', 'TB003', 2, 6, 9, 18, 'Máy D5', 44, NULL, NULL, 'x', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 38, NULL, NULL, NULL, 'SUACHUA', NULL, NULL, '2024-04-24 12:39:26', 1),
(46, 'r11713937168', 'TB004', 2, 6, 9, 18, 'Máy tính xách tay', 44, NULL, NULL, 'x', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 38, NULL, NULL, NULL, 'HOATDONG', NULL, NULL, '2024-04-24 12:39:28', 1),
(47, 'x11713937170', 'TB005', 2, 6, 9, 18, 'Máy in Brother L130', NULL, NULL, NULL, 'x', 'x', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 38, NULL, NULL, NULL, 'SUACHUA', NULL, NULL, '2024-04-24 12:39:30', 1),
(48, 'e11713937172', 'TB006', 2, 6, 9, 18, 'Máy photocopy TOSHIBA', NULL, NULL, NULL, 'x', 'x', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 38, NULL, NULL, NULL, 'HOATDONG', NULL, NULL, '2024-04-24 12:39:32', 1),
(49, 'o11713937174', 'TB007', 2, 6, 9, 18, 'Máy photocopy TOSHIBA', NULL, NULL, 'x', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 38, NULL, NULL, NULL, 'HOATDONG', NULL, NULL, '2024-04-24 12:39:34', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_vi_tri`
--

DROP TABLE IF EXISTS `ts_vi_tri`;
CREATE TABLE IF NOT EXISTS `ts_vi_tri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_vi_tri` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_vi_tri` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mo_ta` text COLLATE utf8_unicode_ci,
  `truc_thuoc` int(11) DEFAULT NULL,
  `da_ngung_hoat_dong` tinyint(1) DEFAULT NULL,
  `ngay_ngung_hoat_dong` date DEFAULT NULL,
  `id_layout` int(11) DEFAULT NULL,
  `toa_do_x` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `toa_do_y` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_layout` (`id_layout`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_vi_tri`
--

INSERT INTO `ts_vi_tri` (`id`, `ma_vi_tri`, `ten_vi_tri`, `mo_ta`, `truc_thuoc`, `da_ngung_hoat_dong`, `ngay_ngung_hoat_dong`, `id_layout`, `toa_do_x`, `toa_do_y`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'MVT', 'Văn phòng đường Nguyễn Đán', '', NULL, 1, '2023-08-01', NULL, '', '', '2023-07-27 14:36:10', 1),
(2, 'VT01', 'Chi nhánh đường Vành Đai', '', NULL, 0, NULL, NULL, '', '', '2023-07-27 14:36:43', 1),
(3, 'VT011', 'Văn phòng Nguyễn Đán', NULL, 0, 0, NULL, NULL, NULL, NULL, '2023-08-02 07:42:31', 1),
(4, 'VT012', 'Phòng Las', NULL, 0, 0, NULL, NULL, NULL, NULL, '2023-08-02 07:42:32', 1),
(5, 'VT013', 'Khu Công Nghiệp', NULL, 0, 1, NULL, NULL, NULL, NULL, '2023-08-02 07:42:32', 1),
(6, 'VT014', 'Trạm trộn', 'Khu vực 1 Khu Công nghiệp', 3, 0, NULL, NULL, NULL, NULL, '2023-08-02 07:42:32', 1),
(7, 'VT015', 'Bãi tập kết xe giao hàng', 'Khu vực 2 Khu Công nghiệp', 1, 1, '2022-08-01', NULL, NULL, NULL, '2023-08-02 07:42:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ts_yeu_cau_van_hanh`
--

DROP TABLE IF EXISTS `ts_yeu_cau_van_hanh`;
CREATE TABLE IF NOT EXISTS `ts_yeu_cau_van_hanh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_nguoi_lap` int(11) NOT NULL,
  `id_nguoi_yeu_cau` int(11) DEFAULT NULL,
  `id_nguoi_gui` int(11) DEFAULT NULL,
  `id_nguoi_duyet` int(11) DEFAULT NULL,
  `id_nguoi_xuat` int(11) DEFAULT NULL,
  `id_nguoi_nhan` int(11) DEFAULT NULL,
  `id_bo_phan_quan_ly` int(11) DEFAULT NULL,
  `cong_trinh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_lap` datetime DEFAULT NULL,
  `ngay_gui` datetime DEFAULT NULL,
  `ngay_duyet` datetime DEFAULT NULL,
  `ngay_xuat` datetime DEFAULT NULL,
  `ngay_nhan` datetime DEFAULT NULL,
  `ly_do` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hieu_luc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noi_dung_lap` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noi_dung_gui` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noi_dung_duyet` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noi_dung_xuat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noi_dung_nhan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_diem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_yeu_cau_van_hanh_nguoi_lap` (`id_nguoi_lap`),
  KEY `fk_yeu_cau_van_hanh_nguoi_yeu_cau` (`id_nguoi_yeu_cau`),
  KEY `fk_yeu_cau_van_hanh_nguoi_gui` (`id_nguoi_gui`),
  KEY `fk_yeu_cau_van_hanh_nguoi_duyet` (`id_nguoi_duyet`),
  KEY `fk_yeu_cau_van_hanh_nguoi_xuat` (`id_nguoi_xuat`),
  KEY `fk_yeu_cau_van_hanh_nguoi_nhan` (`id_nguoi_nhan`),
  KEY `fk_yeu_cau_van_hanh_bo_phan_quan_ly` (`id_bo_phan_quan_ly`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_yeu_cau_van_hanh`
--

INSERT INTO `ts_yeu_cau_van_hanh` (`id`, `id_nguoi_lap`, `id_nguoi_yeu_cau`, `id_nguoi_gui`, `id_nguoi_duyet`, `id_nguoi_xuat`, `id_nguoi_nhan`, `id_bo_phan_quan_ly`, `cong_trinh`, `ngay_lap`, `ngay_gui`, `ngay_duyet`, `ngay_xuat`, `ngay_nhan`, `ly_do`, `hieu_luc`, `noi_dung_lap`, `noi_dung_gui`, `noi_dung_duyet`, `noi_dung_xuat`, `noi_dung_nhan`, `dia_diem`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 45, 38, 4, 38, 4, 1, 'jjjj', '2024-05-30 00:00:00', '2024-05-30 00:00:00', '2024-05-30 00:00:00', '2024-05-31 00:00:00', '2024-06-01 00:00:00', 'mmm', 'VANHANH', 'kkk', 'kkk', 'mmmm', 'mmm', 'mmm', 'nnn', '2024-05-30 22:06:44', '2024-05-30 22:11:31', NULL),
(2, 4, 38, 38, 4, NULL, NULL, 2, 'jjjj', '2024-05-30 00:00:00', '2024-05-31 00:00:00', '2024-05-31 00:00:00', NULL, NULL, 'mm', 'DADUYET', 'nn', 'mm', 'fasdfas', NULL, NULL, 'nnn', '2024-05-30 22:17:55', '2024-05-30 22:28:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ts_yeu_cau_van_hanh_ct`
--

DROP TABLE IF EXISTS `ts_yeu_cau_van_hanh_ct`;
CREATE TABLE IF NOT EXISTS `ts_yeu_cau_van_hanh_ct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_thiet_bi` int(11) NOT NULL,
  `id_yeu_cau_van_hanh` int(11) NOT NULL,
  `ngay_bat_dau` datetime DEFAULT NULL,
  `ngay_ket_thuc` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx-yeu_cau_van_hanh_ct-id_yeu_cau_van_hanh` (`id_yeu_cau_van_hanh`),
  KEY `idx-yeu_cau_van_hanh_ct-id_thiet_bi` (`id_thiet_bi`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ts_yeu_cau_van_hanh_ct`
--

INSERT INTO `ts_yeu_cau_van_hanh_ct` (`id`, `id_thiet_bi`, `id_yeu_cau_van_hanh`, `ngay_bat_dau`, `ngay_ket_thuc`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 43, 1, '2024-05-30 00:00:00', '2024-06-01 00:00:00', '2024-05-30 22:06:44', '2024-05-30 22:07:10', NULL),
(2, 44, 1, '2024-05-30 00:00:00', '2021-06-02 00:00:00', '2024-05-30 22:06:44', '2024-05-30 22:07:10', NULL),
(3, 43, 2, '2024-05-30 00:00:00', '2024-06-01 00:00:00', '2024-05-30 22:17:55', '2024-05-30 22:17:55', NULL),
(4, 44, 2, '2024-05-30 00:00:00', '2024-06-01 00:00:00', '2024-05-30 22:17:55', '2024-05-30 22:17:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) DEFAULT NULL,
  `bind_to_ip` varchar(255) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'superadmin', 'Eh3yGaY9ys2CN7vmFwgJmN1aRu6aaUed', '$2y$13$PSqrfHBcnSig7v3YlWjRG.V5cNWTcCXAvTzS0YNyxudFgkfb91T0W', NULL, 1, 1, 1689001074, 1691109648, NULL, '', '', 0),
(2, 'u001', '0BGuWUbLL_Bf7HL969XStKm4DxEvRWBq', '$2y$13$Q6ZeEK7f/YE2NC8bfWxXZO.pYk/KbPhPWFhjVasFkVchBEdvmo2.y', NULL, 1, 0, 1689045928, 1717078524, '::1', '', 'nguyenvana@gmail.com', 0),
(4, 'user003', 'c0ZYRq8LTpMVn3DZ96-j0__eHQs-rULR', '$2y$13$5oWUaqTVpr3vJTpx0USVMeWrJe6iGjnY7nWfIJrWGtnNw9Nqsn4da', NULL, 1, 0, 1689900390, 1689904172, '::1', '', 'a@gmail.copm', 0),
(6, 'nvc', 'fF9GmW625pEILPsVBLZYKn5MLILlXoix', '$2y$13$JGMS4C4aaL56j9mgbaEfmOFuj9UdAT3W2DrXmxwCo6Oj0s6G.eCym', NULL, 1, 0, 1689904220, 1691653348, '::1', '', '', 0),
(7, 'nvd', 'ebuerhq8ul2W59y3_f3mNTaB2hGII3QM', '$2y$13$HJfu8TuXeMDZZSq5GI8QhOnTfEa4LFUYorIS2QonKuNl1DUhWaD1q', NULL, 1, 0, 1691113587, 1691113587, '::1', '', '', 0),
(20, 'tyan6', 'fxHsO9GfNZtFivBopDwQ6KocqK1yavsu', '$2y$13$pMiVv.kPAMVWhVDiHh7VD./8.6Cdj62I8EkPcdnavC.5UNCSgI2EK', NULL, 1, 0, 1691653806, 1692258835, '::1', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `language` char(2) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) DEFAULT NULL,
  `os` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '64ac1d37ca7e3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689001271, 'Chrome', 'Windows'),
(2, '64acb3bed5ec5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689039806, 'Chrome', 'Windows'),
(3, '64acb70d6a873', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689040653, 'Chrome', 'Windows'),
(4, '64acb737330e5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689040695, 'Chrome', 'Windows'),
(5, '64acb7fcc2409', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689040892, 'Chrome', 'Windows'),
(6, '64acc05a22083', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689043034, 'Chrome', 'Windows'),
(7, '64acc2c941e0d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689043657, 'Chrome', 'Windows'),
(8, '64acc2d28c346', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689043666, 'Chrome', 'Windows'),
(9, '64acc33e167a7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689043774, 'Chrome', 'Windows'),
(10, '64acc486d2377', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689044102, 'Chrome', 'Windows'),
(11, '64acc508bccd5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689044232, 'Chrome', 'Windows'),
(12, '64acc7abc6b9a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689044907, 'Chrome', 'Windows'),
(13, '64acc81c9c590', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689045020, 'Chrome', 'Windows'),
(14, '64acfaedbf81a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689058029, 'Chrome', 'Windows'),
(15, '64ad1150dd4b2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689063760, 'Chrome', 'Windows'),
(16, '64adf89b3beee', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689122971, 'Chrome', 'Windows'),
(17, '64ae020475511', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689125380, 'Chrome', 'Windows'),
(18, '64af6c8ea9c89', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689218190, 'Chrome', 'Windows'),
(19, '64b4a3b7820cf', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689559991, 'Chrome', 'Windows'),
(20, '64b5e052360a0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689641042, 'Chrome', 'Windows'),
(21, '64b636f76975e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689663223, 'Chrome', 'Windows'),
(22, '64b63aafc1b02', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689664175, 'Chrome', 'Windows'),
(23, '64b885dc0428b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689814492, 'Chrome', 'Windows'),
(24, '64b8e9535ecd9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689839955, 'Chrome', 'Windows'),
(25, '64b9d53d212f0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689900349, 'Chrome', 'Windows'),
(26, '64b9dba7de6fb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', NULL, 1689901991, 'Chrome', 'Windows'),
(27, '64b9de5bcea89', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', NULL, 1689902683, 'Chrome', 'Windows'),
(28, '64bb4c7662ea6', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689996406, 'Chrome', 'Windows'),
(29, '64be1ea575fd9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690181285, 'Chrome', 'Windows'),
(30, '64bf34abd0975', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690252459, 'Chrome', 'Windows'),
(31, '64bf41e58e7c4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690255845, 'Chrome', 'Windows'),
(32, '64bf8ea9678e0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690275497, 'Chrome', 'Windows'),
(33, '64bf9ab95a8fb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690278585, 'Chrome', 'Windows'),
(34, '64c06dfd7e0ec', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690332669, 'Chrome', 'Windows'),
(35, '64c1be391be67', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690418745, 'Chrome', 'Windows'),
(36, '64c21d8b3f7d8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690443147, 'Chrome', 'Windows'),
(37, '64c23d7a05552', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1690451322, 'Chrome', 'Windows'),
(38, '64c3262e4f893', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1690510894, 'Chrome', 'Windows'),
(39, '64c370d624b2e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1690530006, 'Chrome', 'Windows'),
(40, '64c474e113efd', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1690596577, 'Chrome', 'Windows'),
(41, '64c7059d5721c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1690764701, 'Chrome', 'Windows'),
(42, '64c85241bfc7f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1690849857, 'Chrome', 'Windows'),
(43, '64c9a0ec86c54', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1690935532, 'Chrome', 'Windows'),
(44, '64caf5e13a179', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691022817, 'Chrome', 'Windows'),
(45, '64cb56ed5789c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691047661, 'Chrome', 'Windows'),
(46, '64cb57fa7db2b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691047930, 'Chrome', 'Windows'),
(47, '64cb733645510', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691054902, 'Chrome', 'Windows'),
(48, '64cc47e9353b2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691109353, 'Chrome', 'Windows'),
(49, '64cc48e552ee3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 6, 1691109605, 'Chrome', 'Windows'),
(50, '64cc490102635', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691109633, 'Chrome', 'Windows'),
(51, '64cc4b05ecb90', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 6, 1691110149, 'Chrome', 'Windows'),
(52, '64ccaac9edc42', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691134665, 'Chrome', 'Windows'),
(53, '64cda83434a78', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691199540, 'Chrome', 'Windows'),
(54, '64d041b1b9263', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691369905, 'Chrome', 'Windows'),
(55, '64d0595fa5457', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 6, 1691375967, 'Chrome', 'Windows'),
(56, '64d1040d65d53', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691419661, 'Chrome', 'Windows'),
(57, '64d1f03bbf342', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691480123, 'Chrome', 'Windows'),
(58, '64d2f9391833d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691547961, 'Chrome', 'Windows'),
(59, '64d435136f9e0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691628819, 'Chrome', 'Windows'),
(60, '64d43541b80e5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', NULL, 1691628865, 'Chrome', 'Windows'),
(61, '64d49416207e1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691653142, 'Chrome', 'Windows'),
(62, '64d494290845c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', NULL, 1691653161, 'Chrome', 'Windows'),
(63, '64d494bd7165f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', NULL, 1691653309, 'Chrome', 'Windows'),
(64, '64d4967f7218b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', NULL, 1691653759, 'Chrome', 'Windows'),
(65, '64d496c2af864', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 20, 1691653826, 'Chrome', 'Windows'),
(66, '64d59601cbbb9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691719169, 'Chrome', 'Windows'),
(67, '64d97d9dac362', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691975069, 'Chrome', 'Windows'),
(68, '64db2183359a1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692082563, 'Chrome', 'Windows'),
(69, '64db2520bab3c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692083488, 'Chrome', 'Windows'),
(70, '64db4773d8d8d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692092275, 'Chrome', 'Windows'),
(71, '64dc3ac344f1f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692154563, 'Chrome', 'Windows'),
(72, '64dc8e47c8fe8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692175943, 'Chrome', 'Windows'),
(73, '64dd6c143c0d1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692232724, 'Chrome', 'Windows'),
(74, '64ddcd0e80eba', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692257550, 'Chrome', 'Windows'),
(75, '64ddd1d206438', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692258770, 'Chrome', 'Windows'),
(76, '64ddd21cbec78', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 20, 1692258844, 'Chrome', 'Windows'),
(77, '64ddd24c8a12b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1692258892, 'Chrome', 'Windows'),
(78, '64df2c13090ac', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', 1, 1692347411, 'Chrome', 'Windows'),
(79, '64e2d34979cf1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', 1, 1692586825, 'Chrome', 'Windows'),
(80, '64e3158bd3f24', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', 1, 1692603787, 'Chrome', 'Windows'),
(81, '651245a619757', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695696294, 'Chrome', 'Windows'),
(82, '65a77cba58e22', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1705475258, 'Chrome', 'Windows'),
(83, '65efabb7b4bd6', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1710205879, 'Chrome', 'Windows'),
(84, '6628729bbda3f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713926811, 'Chrome', 'Windows'),
(85, '66287567e46f3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713927527, 'Chrome', 'Windows'),
(86, '6628912747336', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713934631, 'Chrome', 'Windows'),
(87, '662894f25f4df', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713935602, 'Chrome', 'Windows'),
(88, '66541777d9fd7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716787063, 'Chrome', 'Windows'),
(89, '66588650ad216', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717077584, 'Chrome', 'Windows'),
(90, '66588a04560e7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 2, 1717078532, 'Chrome', 'Windows'),
(91, '665fd01ab435e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717555226, 'Chrome', 'Windows'),
(92, '6661345c5089f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717646428, 'Chrome', 'Windows'),
(93, '667549da657ad', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1718962650, 'Chrome', 'Windows');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ts_bao_gia_sua_chua`
--
ALTER TABLE `ts_bao_gia_sua_chua`
  ADD CONSTRAINT `fk-ts_bao_gia_sua_chua-id_phieu_sua_chua` FOREIGN KEY (`id_phieu_sua_chua`) REFERENCES `ts_phieu_sua_chua` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ts_ct_bao_gia_sua_chua`
--
ALTER TABLE `ts_ct_bao_gia_sua_chua`
  ADD CONSTRAINT `fk-ts_ct_bao_gia_sua_chua-id_bao_gia` FOREIGN KEY (`id_bao_gia`) REFERENCES `ts_bao_gia_sua_chua` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ts_dm_vat_tu`
--
ALTER TABLE `ts_dm_vat_tu`
  ADD CONSTRAINT `fk-ts_dm_vat_tu-id_kho` FOREIGN KEY (`id_kho`) REFERENCES `ts_kho_luu_tru` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ts_doi_tac`
--
ALTER TABLE `ts_doi_tac`
  ADD CONSTRAINT `ts_doi_tac_ibfk_1` FOREIGN KEY (`id_nhom_doi_tac`) REFERENCES `ts_nhom_doi_tac` (`id`);

--
-- Constraints for table `ts_ke_hoach_bao_tri`
--
ALTER TABLE `ts_ke_hoach_bao_tri`
  ADD CONSTRAINT `ts_ke_hoach_bao_tri_ibfk_1` FOREIGN KEY (`id_thiet_bi`) REFERENCES `ts_thiet_bi` (`id`),
  ADD CONSTRAINT `ts_ke_hoach_bao_tri_ibfk_2` FOREIGN KEY (`id_loai_bao_tri`) REFERENCES `ts_loai_bao_tri` (`id`),
  ADD CONSTRAINT `ts_ke_hoach_bao_tri_ibfk_3` FOREIGN KEY (`id_don_vi_bao_tri`) REFERENCES `ts_bo_phan` (`id`),
  ADD CONSTRAINT `ts_ke_hoach_bao_tri_ibfk_4` FOREIGN KEY (`id_nguoi_chiu_trach_nhiem`) REFERENCES `ts_nhan_vien` (`id`);

--
-- Constraints for table `ts_kho_luu_tru`
--
ALTER TABLE `ts_kho_luu_tru`
  ADD CONSTRAINT `ts_kho_luu_tru_ibfk_1` FOREIGN KEY (`id_bo_phan_quan_ly`) REFERENCES `ts_bo_phan` (`id`),
  ADD CONSTRAINT `ts_kho_luu_tru_ibfk_2` FOREIGN KEY (`id_nguoi_quan_ly`) REFERENCES `ts_nhan_vien` (`id`);

--
-- Constraints for table `ts_lich_su_vat_tu`
--
ALTER TABLE `ts_lich_su_vat_tu`
  ADD CONSTRAINT `fk-ts_lich_su_vat_tu-id_vat_tu` FOREIGN KEY (`id_vat_tu`) REFERENCES `ts_dm_vat_tu` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-ts_lich_su_vat_tu-nguoi_tao` FOREIGN KEY (`nguoi_tao`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ts_nhan_vien`
--
ALTER TABLE `ts_nhan_vien`
  ADD CONSTRAINT `ts_nhan_vien_ibfk_1` FOREIGN KEY (`id_bo_phan`) REFERENCES `ts_bo_phan` (`id`);

--
-- Constraints for table `ts_nhan_vien_kho`
--
ALTER TABLE `ts_nhan_vien_kho`
  ADD CONSTRAINT `ts_nhan_vien_kho_ibfk_1` FOREIGN KEY (`id_kho`) REFERENCES `ts_kho_luu_tru` (`id`),
  ADD CONSTRAINT `ts_nhan_vien_kho_ibfk_2` FOREIGN KEY (`id_nhan_vien`) REFERENCES `ts_nhan_vien` (`id`);

--
-- Constraints for table `ts_phieu_bao_tri`
--
ALTER TABLE `ts_phieu_bao_tri`
  ADD CONSTRAINT `fk-ts_phieu_bao_tri-id_ke_hoach` FOREIGN KEY (`id_ke_hoach`) REFERENCES `ts_ke_hoach_bao_tri` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ts_phieu_sua_chua`
--
ALTER TABLE `ts_phieu_sua_chua`
  ADD CONSTRAINT `fk-ts_phieu_sua_chua-id_thiet_bi` FOREIGN KEY (`id_thiet_bi`) REFERENCES `ts_thiet_bi` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-ts_phieu_sua_chua-id_tt_sua_chua` FOREIGN KEY (`id_tt_sua_chua`) REFERENCES `ts_dm_tt_sua_chua` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ts_phieu_sua_chua_vat_tu`
--
ALTER TABLE `ts_phieu_sua_chua_vat_tu`
  ADD CONSTRAINT `fk-ts_phieu_sua_chua_vat_tu-id_phieu_sua_chua` FOREIGN KEY (`id_phieu_sua_chua`) REFERENCES `ts_phieu_sua_chua` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-ts_phieu_sua_chua_vat_tu-id_vat_tu` FOREIGN KEY (`id_vat_tu`) REFERENCES `ts_dm_vat_tu` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ts_thiet_bi`
--
ALTER TABLE `ts_thiet_bi`
  ADD CONSTRAINT `ts_thiet_bi_ibfk_1` FOREIGN KEY (`id_loai_thiet_bi`) REFERENCES `ts_loai_thiet_bi` (`id`),
  ADD CONSTRAINT `ts_thiet_bi_ibfk_2` FOREIGN KEY (`id_bo_phan_quan_ly`) REFERENCES `ts_bo_phan` (`id`),
  ADD CONSTRAINT `ts_thiet_bi_ibfk_3` FOREIGN KEY (`id_nguoi_quan_ly`) REFERENCES `ts_nhan_vien` (`id`);

--
-- Constraints for table `ts_yeu_cau_van_hanh`
--
ALTER TABLE `ts_yeu_cau_van_hanh`
  ADD CONSTRAINT `fk_yeu_cau_van_hanh_bo_phan_quan_ly` FOREIGN KEY (`id_bo_phan_quan_ly`) REFERENCES `ts_bo_phan` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_yeu_cau_van_hanh_nguoi_duyet` FOREIGN KEY (`id_nguoi_duyet`) REFERENCES `ts_nhan_vien` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_yeu_cau_van_hanh_nguoi_gui` FOREIGN KEY (`id_nguoi_gui`) REFERENCES `ts_nhan_vien` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_yeu_cau_van_hanh_nguoi_lap` FOREIGN KEY (`id_nguoi_lap`) REFERENCES `ts_nhan_vien` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_yeu_cau_van_hanh_nguoi_nhan` FOREIGN KEY (`id_nguoi_nhan`) REFERENCES `ts_nhan_vien` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_yeu_cau_van_hanh_nguoi_xuat` FOREIGN KEY (`id_nguoi_xuat`) REFERENCES `ts_nhan_vien` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_yeu_cau_van_hanh_nguoi_yeu_cau` FOREIGN KEY (`id_nguoi_yeu_cau`) REFERENCES `ts_nhan_vien` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `ts_yeu_cau_van_hanh_ct`
--
ALTER TABLE `ts_yeu_cau_van_hanh_ct`
  ADD CONSTRAINT `fk-yeu_cau_van_hanh_ct-id_thiet_bi` FOREIGN KEY (`id_thiet_bi`) REFERENCES `ts_thiet_bi` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-yeu_cau_van_hanh_ct-id_yeu_cau_van_hanh` FOREIGN KEY (`id_yeu_cau_van_hanh`) REFERENCES `ts_yeu_cau_van_hanh` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
