-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 10, 2023 at 11:36 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlts`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//controller', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//crud', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//extension', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//form', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//model', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('//module', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/asset/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/asset/compress', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/asset/template', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/cache/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/cache/flush', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/cache/flush-all', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/cache/flush-schema', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/cache/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/fixture/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/fixture/load', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/fixture/unload', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/hello/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/hello/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/help/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/help/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/help/list', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/help/list-action-options', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/help/usage', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/message/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/message/config', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/message/config-template', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/message/extract', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/create', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/down', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/fresh', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/history', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/mark', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/new', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/redo', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/to', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/migrate/up', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/serve/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/serve/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1689001075, 1689001075, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1689001075, 1689001075, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1689001075, 1689001075, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1689001074, 1689001074, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1689001075, 1689001075, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1689001075, 1689001075, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1689001075, 1689001075),
('userManagement', 'User management', 1689001075, 1689001075);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1689001070),
('m140608_173539_create_user_table', 1689001073),
('m140611_133903_init_rbac', 1689001073),
('m140808_073114_create_auth_item_group_table', 1689001074),
('m140809_072112_insert_superadmin_to_user', 1689001074),
('m140809_073114_insert_common_permisison_to_auth_item', 1689001074),
('m141023_141535_create_user_visit_log', 1689001074),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1689001074),
('m141121_194858_split_browser_and_os_column', 1689001075),
('m141201_220516_add_email_and_email_confirmed_to_user', 1689001075),
('m141207_001649_create_basic_user_permissions', 1689001075);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) DEFAULT NULL,
  `bind_to_ip` varchar(255) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'superadmin', 'Eh3yGaY9ys2CN7vmFwgJmN1aRu6aaUed', '$2y$13$tTb2OHDmbOK.OACF3j2uSuV09TRaUtQh2JZzOTJxR40exkK9V0DHi', NULL, 1, 1, 1689001074, 1689001074, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `language` char(2) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) DEFAULT NULL,
  `os` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '64ac1d37ca7e3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689001271, 'Chrome', 'Windows');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
